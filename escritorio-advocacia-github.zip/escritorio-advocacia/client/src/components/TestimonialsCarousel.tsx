import { Star } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { MapView } from "./Map";

interface Review {
  id: string;
  name: string;
  rating: number;
  text: string;
  date: string;
  photoUrl?: string;
}

export default function TestimonialsCarousel() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [reviews, setReviews] = useState<Review[]>([
    {
      id: "1",
      name: "Carlos Eduardo",
      rating: 5,
      text: "Excelente atendimento! Profissionais muito competentes e atenciosos. Resolveram meu caso com agilidade.",
      date: "há 2 semanas"
    },
    {
      id: "2",
      name: "Mariana Silva",
      rating: 5,
      text: "O Dr. Djair é um advogado excepcional. Recomendo fortemente para quem precisa de assessoria jurídica séria.",
      date: "há 1 mês"
    },
    {
      id: "3",
      name: "João Paulo",
      rating: 5,
      text: "Equipe muito preparada. Me senti seguro durante todo o processo. Transparência e ética definem este escritório.",
      date: "há 3 meses"
    }
  ]);

  // Fetch real reviews from Google Places API via MapView
  const handleMapReady = (map: google.maps.Map) => {
    const service = new google.maps.places.PlacesService(map);
    const request = {
      query: "Djair Rota Advogados Mococa",
      fields: ["name", "place_id"]
    };

    service.findPlaceFromQuery(request, (results, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK && results && results[0]) {
        const placeId = results[0].place_id;
        if (placeId) {
          service.getDetails({
            placeId: placeId,
            fields: ["reviews"]
          }, (place, status) => {
            if (status === google.maps.places.PlacesServiceStatus.OK && place && place.reviews) {
              const googleReviews = place.reviews.map((review: any) => ({
                id: review.time.toString(),
                name: review.author_name,
                rating: review.rating,
                text: review.text,
                date: review.relative_time_description,
                photoUrl: review.profile_photo_url
              }));
              // Filter only 5-star reviews and update state
              setReviews(googleReviews.filter((r: Review) => r.rating >= 4).slice(0, 6));
            }
          });
        }
      }
    });
  };

  // Auto-rotate carousel logic
  useEffect(() => {
    if (reviews.length === 0) return;
    
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % reviews.length);
    }, 4000); // Rotate every 4 seconds
    
    return () => clearInterval(interval);
  }, [reviews.length]);

  // Calculate visible reviews based on active index (showing 3 at a time on desktop)
  const getVisibleReviews = () => {
    if (reviews.length === 0) return [];
    
    const visible = [];
    for (let i = 0; i < 3; i++) {
      const index = (activeIndex + i) % reviews.length;
      visible.push(reviews[index]);
    }
    return visible;
  };

  return (
    <section className="py-24 bg-background overflow-hidden">
      <div className="container">
        <div className="flex flex-col items-center text-center mb-16">
          <h2 className="text-4xl font-serif text-primary mb-4">O que dizem nossos clientes</h2>
          <div className="flex items-center gap-2 text-yellow-500 mb-2">
            <span className="text-2xl font-bold text-primary">4.9</span>
            <div className="flex">
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} className="h-5 w-5 fill-current" />
              ))}
            </div>
          </div>
          <p className="text-sm text-muted-foreground uppercase tracking-widest">
            Baseado em avaliações do Google
          </p>
        </div>

        {/* Hidden Map for API Access */}
        <div className="hidden">
          <MapView onMapReady={handleMapReady} />
        </div>

        {/* Carousel Container */}
        <div className="relative w-full max-w-6xl mx-auto">
          {/* Desktop Carousel (3 cards sliding) */}
          <div className="hidden md:grid grid-cols-3 gap-8 transition-all duration-500 ease-in-out">
            {getVisibleReviews().map((review, i) => (
              <div key={`${review.id}-${i}`} className="animate-in fade-in slide-in-from-right-4 duration-500">
                <TestimonialCard testimonial={review} />
              </div>
            ))}
          </div>

          {/* Mobile Carousel (1 card sliding) */}
          <div className="md:hidden relative h-[350px]">
            {reviews.map((review, index) => (
              <div
                key={review.id}
                className={cn(
                  "absolute inset-0 transition-all duration-500 ease-in-out transform px-4",
                  index === activeIndex 
                    ? "opacity-100 translate-x-0 z-10" 
                    : "opacity-0 translate-x-full pointer-events-none z-0"
                )}
              >
                <TestimonialCard testimonial={review} />
              </div>
            ))}
          </div>

          {/* Indicators */}
          <div className="flex justify-center gap-2 mt-12">
            {reviews.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={cn(
                  "h-2 rounded-full transition-all duration-300",
                  index === activeIndex ? "bg-primary w-8" : "bg-primary/20 w-2 hover:bg-primary/40"
                )}
                aria-label={`Ver depoimento ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

function TestimonialCard({ testimonial }: { testimonial: Review }) {
  return (
    <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-[0_2px_8px_rgba(0,0,0,0.08)] h-full flex flex-col font-sans">
      <div className="flex items-start gap-3 mb-3">
        {testimonial.photoUrl ? (
          <img 
            src={testimonial.photoUrl} 
            alt={testimonial.name} 
            className="h-10 w-10 rounded-full object-cover"
          />
        ) : (
          <div className="h-10 w-10 rounded-full bg-[#7B1FA2] flex items-center justify-center text-white font-medium text-lg">
            {testimonial.name.charAt(0)}
          </div>
        )}
        <div className="flex-1 min-w-0">
          <h4 className="font-bold text-sm text-gray-900 truncate">{testimonial.name}</h4>
          <div className="flex items-center gap-1 text-xs text-gray-500">
            <span>{testimonial.date}</span>
          </div>
        </div>
        <img 
          src="https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_%22G%22_logo.svg" 
          alt="Google" 
          className="h-5 w-5" 
        />
      </div>
      
      <div className="flex items-center gap-1 mb-3">
        <div className="flex text-[#FBBC04]">
          {[...Array(5)].map((_, i) => (
            <Star 
              key={i} 
              className={cn(
                "h-4 w-4 fill-current", 
                i < testimonial.rating ? "text-[#FBBC04]" : "text-gray-300"
              )} 
            />
          ))}
        </div>
      </div>
      
      <p className="text-gray-600 text-sm leading-relaxed flex-grow line-clamp-4">
        {testimonial.text}
      </p>
    </div>
  );
}
