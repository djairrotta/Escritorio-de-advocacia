import { Link, useLocation } from "wouter";
import { Users, FileText, FolderOpen, CheckSquare, MessageSquare, Calendar, Home, LogOut, Shield, Settings, Bell, MessageCircle, Mail, BarChart3, Database, Clock, PieChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface SidebarProps {
  onLogout: () => void;
}

export default function Sidebar({ onLogout }: SidebarProps) {
  const [location] = useLocation();

  const userRole = localStorage.getItem("advogado_role");
  const isAdminUser = userRole === "Master" || userRole === "Moderador";

  // Contador de notificações não lidas (mockado - pode ser substituído por API real)
  const unreadNotifications = 3;

  // Calcular indicadores de atividade
  const activityIndicators = {
    newClients: 0,
    upcomingDeadlines: 0,
    overdueTasks: 0
  };

  // Novos clientes cadastrados hoje
  try {
    const clients = JSON.parse(localStorage.getItem('clients') || '[]');
    const today = new Date().toDateString();
    activityIndicators.newClients = clients.filter((c: any) => {
      const createdDate = new Date(c.createdAt || c.cadastro || Date.now()).toDateString();
      return createdDate === today;
    }).length;
  } catch (e) {
    console.error('Erro ao calcular novos clientes:', e);
  }

  // Processos com prazos próximos (próximos 7 dias)
  try {
    const processes = JSON.parse(localStorage.getItem('processes') || '[]');
    const now = new Date();
    const sevenDaysFromNow = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
    
    activityIndicators.upcomingDeadlines = processes.filter((p: any) => {
      if (!p.deadline && !p.prazo) return false;
      const deadline = new Date(p.deadline || p.prazo);
      return deadline >= now && deadline <= sevenDaysFromNow;
    }).length;
  } catch (e) {
    console.error('Erro ao calcular prazos próximos:', e);
  }

  // Tarefas atrasadas
  try {
    const tasks = JSON.parse(localStorage.getItem('tasks') || '[]');
    const now = new Date();
    
    activityIndicators.overdueTasks = tasks.filter((t: any) => {
      if (t.status === 'concluída' || t.status === 'Concluída') return false;
      if (!t.dueDate && !t.prazo) return false;
      const dueDate = new Date(t.dueDate || t.prazo);
      return dueDate < now;
    }).length;
  } catch (e) {
    console.error('Erro ao calcular tarefas atrasadas:', e);
  }

  const menuItems = [
    { icon: Home, label: "Dashboard", href: "/advogados/dashboard" },
    { icon: Users, label: "Clientes", href: "/advogados/clientes" },
    { icon: FileText, label: "Processos", href: "/advogados/processos" },
    { icon: FolderOpen, label: "Documentos", href: "/advogados/documentos" },
    { icon: PieChart, label: "Estatísticas", href: "/advogados/estatisticas" },
    { icon: CheckSquare, label: "Tarefas", href: "/advogados/tarefas" },
    { icon: MessageSquare, label: "Atendimento", href: "/advogados/atendimento" },
    { icon: MessageCircle, label: "Mensagens", href: "/advogados/mensagens" },
    { icon: Calendar, label: "Audiências", href: "/advogados/audiencias" },
    { icon: Calendar, label: "Calendário", href: "/advogados/calendario" },
    ...(isAdminUser ? [{ icon: Clock, label: "Agendamentos", href: "/advogados/agendamentos-disponiveis" }] : []),
    { icon: Mail, label: "E-mail", href: "/advogados/email" },
    { icon: Bell, label: "Notificações", href: "/advogados/notificacoes" },
    { icon: Bell, label: "Dashboard Notificações", href: "/advogados/notificacoes-dashboard" },
  ];

  // Adicionar itens administrativos apenas para Master/Moderador
  if (isAdminUser) {
    menuItems.push({ icon: Shield, label: "Logs de Auditoria", href: "/advogados/logs" });
    menuItems.push({ icon: Settings, label: "Configurações", href: "/advogados/configuracoes" });
  }

  // Adicionar WhatsApp Config, Relatórios, Lembretes e Backups apenas para Master
  if (userRole === "Master") {
    menuItems.push({ icon: MessageCircle, label: "WhatsApp API", href: "/advogados/whatsapp-config" });
    menuItems.push({ icon: BarChart3, label: "Relatórios", href: "/advogados/relatorios" });
    menuItems.push({ icon: Bell, label: "Lembretes", href: "/advogados/lembretes" });
    menuItems.push({ icon: Database, label: "Backups", href: "/advogados/backups" });
  }

  const isActive = (href: string) => location === href;

  return (
    <aside className="w-64 bg-slate-900 text-white min-h-screen flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-slate-700">
        <Link href="/advogados/dashboard">
          <div className="flex items-center gap-3 cursor-pointer">
            <img 
              src="/images/logo-transparent.png" 
              alt="Logo" 
              className="h-10 w-auto object-contain filter brightness-0 invert" 
            />
            <div>
              <h2 className="font-serif text-lg font-bold">Djair Rota</h2>
              <p className="text-xs text-slate-400">Advogados</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Menu */}
      <nav className="flex-1 py-4 overflow-y-auto">
        <ul className="space-y-0.5 px-3">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const active = isActive(item.href);
            
            return (
              <li key={item.href}>
                <Link href={item.href}>
                  <div
                    className={`flex items-center gap-2 px-2 py-1.5 rounded-lg transition-all cursor-pointer ${
                      active
                        ? "bg-slate-800 text-white font-semibold"
                        : "text-slate-300 hover:bg-slate-800/50 hover:text-white"
                    }`}
                  >
                    <div className="relative">
                      <Icon className="h-3.5 w-3.5" />
                      {/* Badge de notificações não lidas apenas no item "Notificações" */}
                      {item.label === "Notificações" && unreadNotifications > 0 && (
                        <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center">
                          {unreadNotifications}
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] uppercase tracking-wide flex-1">{item.label}</span>
                    
                    {/* Indicadores de atividade */}
                    {item.label === "Clientes" && activityIndicators.newClients > 0 && (
                      <div className="relative group">
                        <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
                        <div className="absolute right-0 top-6 hidden group-hover:block z-50 bg-slate-800 text-white text-[10px] px-2 py-1 rounded whitespace-nowrap shadow-lg border border-slate-600">
                          {activityIndicators.newClients} novo{activityIndicators.newClients > 1 ? 's' : ''} hoje
                        </div>
                      </div>
                    )}
                    
                    {item.label === "Processos" && activityIndicators.upcomingDeadlines > 0 && (
                      <div className="relative group">
                        <div className="h-2 w-2 rounded-full bg-yellow-500 animate-pulse" />
                        <div className="absolute right-0 top-6 hidden group-hover:block z-50 bg-slate-800 text-white text-[10px] px-2 py-1 rounded whitespace-nowrap shadow-lg border border-slate-600">
                          {activityIndicators.upcomingDeadlines} prazo{activityIndicators.upcomingDeadlines > 1 ? 's' : ''} próximo{activityIndicators.upcomingDeadlines > 1 ? 's' : ''}
                        </div>
                      </div>
                    )}
                    
                    {item.label === "Tarefas" && activityIndicators.overdueTasks > 0 && (
                      <div className="relative group">
                        <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
                        <div className="absolute right-0 top-6 hidden group-hover:block z-50 bg-slate-800 text-white text-[10px] px-2 py-1 rounded whitespace-nowrap shadow-lg border border-slate-600">
                          {activityIndicators.overdueTasks} atrasada{activityIndicators.overdueTasks > 1 ? 's' : ''}
                        </div>
                      </div>
                    )}
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      {/* User Info & Logout */}
      <div className="p-4 border-t border-slate-700">
        <div className="flex items-center gap-3 mb-3 px-2">
          <div className="h-10 w-10 rounded-full bg-slate-700 flex items-center justify-center text-white font-bold">
            {(localStorage.getItem("advogado_name") || "U").charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate">{localStorage.getItem("advogado_name") || "Usuário"}</p>
            <p className="text-xs text-slate-400 truncate">{localStorage.getItem("advogado_role") || "Advogado"}</p>
          </div>
        </div>
        <Button
          variant="ghost"
          className="w-full justify-start text-slate-300 hover:bg-slate-800 hover:text-white"
          onClick={onLogout}
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sair
        </Button>
      </div>
    </aside>
  );
}
