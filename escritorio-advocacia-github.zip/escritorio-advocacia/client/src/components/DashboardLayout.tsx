import { useEffect } from "react";
import { useLocation } from "wouter";
import Sidebar from "./Sidebar";
import { Button } from "@/components/ui/button";
import { LogOut } from "lucide-react";
import { toast } from "sonner";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const isAuth = localStorage.getItem("advogado_auth");
    if (!isAuth) {
      setLocation("/advogados");
    }
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("advogado_auth");
    localStorage.removeItem("advogado_name");
    localStorage.removeItem("advogado_role");
    localStorage.removeItem("advogado_user_id");
    localStorage.removeItem("advogado_email");
    toast.success("Logout realizado com sucesso");
    setLocation("/");
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <Sidebar onLogout={handleLogout} />
      <main className="flex-1 relative">
        {/* Botão Sair - Canto Superior Direito */}
        <div className="sticky top-0 right-0 w-full h-20 pointer-events-none z-40 bg-slate-50">
          <Button
            onClick={handleLogout}
            className="absolute top-6 right-6 pointer-events-auto bg-blue-600 hover:bg-blue-700 text-white shadow-lg"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Sair
          </Button>
        </div>
        <div>
          {children}
        </div>
      </main>
    </div>
  );
}
