import { useState, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { logAuditAction, canPerformCriticalOperation } from "@/lib/permissions";
import type { LegalCase } from "@/types";
import { mockClients, mockUsers } from "@/data/mockData";
import { notifyProcessUpdate } from "@/lib/notificationService";
import { Upload, X, FileText } from "lucide-react";
import { Card } from "@/components/ui/card";

interface ProcessFormProps {
  process?: LegalCase;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function ProcessForm({ process, onSuccess, onCancel }: ProcessFormProps) {
  const isEdit = !!process;
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<{
    caseNumber: string;
    title: string;
    clientId: string;
    area: string;
    status: "ativo" | "arquivado" | "concluído";
    lawyerId: string;
    description: string;
  }>({
    caseNumber: process?.caseNumber || "",
    title: process?.title || "",
    clientId: process?.client?.id?.toString() || "",
    area: process?.area || "",
    status: (process?.status || "ativo") as "ativo" | "arquivado" | "concluído",
    lawyerId: process?.assignedTo?.id?.toString() || "",
    description: process?.description || "",
  });

  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      // Tipos de arquivo permitidos: documentos, imagens, vídeos e áudios
      const allowedTypes = [
        // Documentos
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        // Imagens
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
        // Vídeos
        'video/mp4',
        'video/avi',
        'video/quicktime', // .mov
        'video/x-matroska', // .mkv
        'video/webm',
        'video/x-msvideo',
        // Áudios
        'audio/mpeg', // .mp3
        'audio/wav',
        'audio/x-wav',
        'audio/mp4', // .m4a
        'audio/ogg',
        'audio/webm'
      ];
      
      const isValidType = allowedTypes.includes(file.type);
      
      if (!isValidType) {
        toast.error(`${file.name}: Tipo de arquivo não permitido`);
        return false;
      }
      
      return true;
    });
    
    setUploadedFiles(prev => [...prev, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!canPerformCriticalOperation()) {
      toast.error("Você não tem permissão para esta operação");
      return;
    }

    setLoading(true);

    try {
      // Upload de documentos para S3 (se houver)
      if (uploadedFiles.length > 0) {
        toast.info(`Enviando ${uploadedFiles.length} documento(s)...`);
        
        const processId = process?.id || Date.now();
        const clientId = formData.clientId;
        
        for (const file of uploadedFiles) {
          const formDataUpload = new FormData();
          formDataUpload.append('file', file);
          formDataUpload.append('clientId', clientId.toString());
          formDataUpload.append('caseId', processId.toString());
          
          try {
            const response = await fetch('/api/upload-case-document', {
              method: 'POST',
              body: formDataUpload,
            });
            
            if (!response.ok) {
              throw new Error(`Falha ao enviar ${file.name}`);
            }
            
            const data = await response.json();
            console.log(`Arquivo ${file.name} enviado:`, data.fileUrl);
          } catch (error) {
            console.error(`Erro ao enviar ${file.name}:`, error);
            toast.error(`Erro ao enviar ${file.name}`);
          }
        }
        
        toast.success(`${uploadedFiles.length} documento(s) enviado(s) com sucesso!`);
      }
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
    }

    setTimeout(() => {
      const action = isEdit ? "editar" : "criar";
      const processId = process?.id || Date.now();
      
      logAuditAction(
        action,
        "processo",
        processId,
        `${formData.caseNumber} - ${formData.title}`
      );

      toast.success(`Processo ${isEdit ? "atualizado" : "cadastrado"} com sucesso!`);
      
      // Enviar notificação ao cliente
      const client = mockClients.find(c => c.id.toString() === formData.clientId);
      if (client && isEdit) {
        notifyProcessUpdate(
          client.name,
          client.email,
          client.phone,
          formData.caseNumber,
          "status_alterado",
          `O processo foi atualizado. Novo status: ${formData.status}. ${formData.description ? 'Detalhes: ' + formData.description : ''}`
        ).then(() => {
          toast.info("Notificação enviada ao cliente");
        }).catch(() => {
          toast.warning("Processo salvo, mas notificação não foi enviada");
        });
      }
      
      setLoading(false);
      onSuccess();
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="caseNumber">Número do Processo *</Label>
          <Input
            id="caseNumber"
            value={formData.caseNumber}
            onChange={(e) => setFormData({ ...formData, caseNumber: e.target.value })}
            required
            placeholder="0001234-56.2024.8.26.0000"
          />
        </div>

        <div>
          <Label htmlFor="status">Status *</Label>
          <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as "ativo" | "arquivado" | "concluído" })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ativo">Ativo</SelectItem>
              <SelectItem value="arquivado">Arquivado</SelectItem>
              <SelectItem value="concluído">Concluído</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="col-span-2">
          <Label htmlFor="title">Título do Processo *</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            required
            placeholder="Ex: Ação Trabalhista - Rescisão Indireta"
          />
        </div>

        <div>
          <Label htmlFor="clientId">Cliente *</Label>
          <Select value={formData.clientId} onValueChange={(value) => setFormData({ ...formData, clientId: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o cliente" />
            </SelectTrigger>
            <SelectContent>
              {mockClients.map((client) => (
                <SelectItem key={client.id} value={client.id.toString()}>
                  {client.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="area">Área do Direito *</Label>
          <Select value={formData.area} onValueChange={(value) => setFormData({ ...formData, area: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione a área" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Trabalhista">Trabalhista</SelectItem>
              <SelectItem value="Civil">Civil</SelectItem>
              <SelectItem value="Família">Família</SelectItem>
              <SelectItem value="Criminal">Criminal</SelectItem>
              <SelectItem value="Empresarial">Empresarial</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="col-span-2">
          <Label htmlFor="lawyerId">Advogado Responsável *</Label>
          <Select value={formData.lawyerId} onValueChange={(value) => setFormData({ ...formData, lawyerId: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o advogado" />
            </SelectTrigger>
            <SelectContent>
              {mockUsers.map((user) => (
                <SelectItem key={user.id} value={user.id.toString()}>
                  {user.name} ({user.role})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="col-span-2">
          <Label htmlFor="description">Descrição</Label>
          <Textarea
            id="description"
            value={formData.description}
            onChange={(e) => setFormData({ ...formData, description: e.target.value })}
            placeholder="Resumo do caso e informações relevantes..."
            rows={4}
          />
        </div>

        {/* Upload de Documentos do Processo */}
        <div className="col-span-2">
          <Label>Documentos do Processo (Opcional)</Label>
          <Card className="p-4 border-2 border-dashed border-slate-300 hover:border-slate-400 transition-colors">
            <div className="flex flex-col items-center justify-center gap-3">
              <Upload className="h-8 w-8 text-slate-400" />
              <div className="text-center">
                <p className="text-sm text-slate-600 mb-1">
                  Arraste arquivos ou clique para selecionar
                </p>
                <p className="text-xs text-slate-500">
                  Petições, contratos, provas, etc. (PDF, JPG, PNG, DOC - máx. 10MB)
                </p>
              </div>
              <Input
                type="file"
                multiple
                accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                onChange={handleFileChange}
                className="hidden"
                id="process-file-upload"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => document.getElementById('process-file-upload')?.click()}
              >
                Selecionar Arquivos
              </Button>
            </div>
          </Card>

          {/* Lista de arquivos selecionados */}
          {uploadedFiles.length > 0 && (
            <div className="mt-3 space-y-2">
              <Label className="text-sm font-semibold">Arquivos Selecionados ({uploadedFiles.length})</Label>
              {uploadedFiles.map((file, index) => (
                <Card key={index} className="p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-slate-600" />
                    <div>
                      <p className="text-sm font-medium text-slate-800">{file.name}</p>
                      <p className="text-xs text-slate-500">
                        {(file.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                  >
                    <X className="h-4 w-4 text-red-500" />
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
        <Button type="submit" disabled={loading} className="flex-1 bg-slate-800 hover:bg-slate-900">
          {loading ? "Salvando..." : isEdit ? "Atualizar" : "Cadastrar"}
        </Button>
      </div>
    </form>
  );
}
