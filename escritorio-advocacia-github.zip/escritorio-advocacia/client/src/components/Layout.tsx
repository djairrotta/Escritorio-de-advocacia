import { Link, useLocation } from "wouter";
import { trackEvent } from "./GoogleAnalytics";
import { cn } from "@/lib/utils";
import { Search, Menu, X } from "lucide-react";
import { useState, useEffect } from "react";

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  // Check if current page is Home
  const isHome = location === "/";

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { href: "/", label: "Home" },
    { href: "/atuacao", label: "Atuação" },
    { href: "/equipe", label: "Advogados" }, // "Lawyers" (implied)
    { href: "/sobre", label: "O Escritório" }, // "The Firm"

    { href: "/contato", label: "Contato" },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans bg-background text-foreground">
      {/* Header - Transparent on Home (until scroll), Solid on other pages */}
      <header className={cn(
        "fixed top-0 z-50 w-full transition-all duration-300",
        (isScrolled || !isHome) ? "bg-primary/95 backdrop-blur-sm shadow-md py-0" : "bg-transparent py-4"
      )}>
        <div className="w-full px-8 flex h-24 items-center justify-between">
          {/* Logo - Left Aligned, Serif, Elegant */}
          <Link href="/" className="flex flex-col items-start group">
            <img src="/images/logo-transparent.png" alt="Djair Rota Advogados" className="h-12 md:h-16 w-auto object-contain" />
          </Link>

          {/* Desktop Actions - Right Aligned */}
          <div className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-6 text-xs font-bold tracking-widest uppercase">
              <Link 
                href="/cliente"
                className="text-white hover:text-white/80 transition-colors border border-white/30 px-4 py-2 rounded-sm hover:bg-white/5"
              >
                Clientes
              </Link>
              <Link 
                href="/advogados"
                className="text-white hover:text-white/80 transition-colors border border-white/30 px-4 py-2 rounded-sm hover:bg-white/5"
              >
                Advogados
              </Link>
            </div>
            <button className="hover:opacity-70 transition-opacity" aria-label="Pesquisar">
              <Search className="h-5 w-5" />
            </button>
            <button 
              className="flex items-center gap-2 hover:opacity-70 transition-opacity"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              aria-label="Abrir menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            className="md:hidden p-2 text-primary-foreground"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label={isMenuOpen ? "Fechar menu" : "Abrir menu"}
          >
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </header>

      {/* Full Screen Menu Overlay */}
      <div className={cn(
        "fixed inset-0 z-40 bg-primary text-primary-foreground pt-32 px-8 transition-transform duration-500 ease-in-out transform",
        isMenuOpen ? "translate-x-0" : "translate-x-full"
      )}>
        <nav className="container flex flex-col gap-8">
          {navItems.map((item) => (
            <Link 
              key={item.href} 
              href={item.href}
              className="text-3xl md:text-5xl font-serif hover:opacity-70 transition-opacity border-b border-white/10 pb-4"
              onClick={() => setIsMenuOpen(false)}
            >
              {item.label}
            </Link>
          ))}
          <div className="flex flex-col gap-4 mt-8">
            <Link 
              href="/cliente"
              className="text-xl font-bold uppercase tracking-widest hover:opacity-70 transition-opacity"
              onClick={() => setIsMenuOpen(false)}
            >
              Acesso Clientes
            </Link>
            <Link 
              href="/advogados"
              className="text-xl font-bold uppercase tracking-widest hover:opacity-70 transition-opacity"
              onClick={() => setIsMenuOpen(false)}
            >
              Acesso Advogados
            </Link>
          </div>
        </nav>
      </div>

      {/* Main Content - Push down due to fixed header */}
      <main className="flex-1">{children}</main>

      {/* Footer - Dark Petrol Blue */}
      <footer className="bg-primary text-primary-foreground py-16 border-t border-white/10">
        <div className="container grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="space-y-6">
            <div className="flex flex-col items-start">
              <img src="/images/logo-transparent.png" alt="Djair Rota Advogados" className="h-12 w-auto object-contain" />
            </div>
            <p className="text-sm opacity-70 leading-relaxed max-w-xs">
              Compromisso com a excelência e visão global para soluções jurídicas complexas.
            </p>
          </div>

          <div>
            <h4 className="font-serif text-lg mb-6 opacity-90">Escritório</h4>
            <ul className="space-y-3 text-sm opacity-70">
              <li><Link href="/sobre" className="hover:underline">Sobre Nós</Link></li>
              <li><Link href="/equipe" className="hover:underline">Profissionais</Link></li>
              <li><Link href="/atuacao" className="hover:underline">Áreas de Atuação</Link></li>

            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg mb-6 opacity-90">Contato</h4>
            <ul className="space-y-3 text-sm opacity-70">
              <li>Rua Coronel Diogo, 525</li>
              <li>Mococa - SP</li>
              <li><a href="https://wa.me/551936564903" target="_blank" rel="noopener noreferrer" className="hover:underline" onClick={() => trackEvent('whatsapp_click', { location: 'footer_phone' })}>19 3656-4903</a></li>
              <li>djair@djairrotta.com.br</li>
            </ul>
          </div>

          <div>
            <h4 className="font-serif text-lg mb-6 opacity-90">Legal</h4>
            <ul className="space-y-3 text-sm opacity-70">
              <li><Link href="/politica-privacidade" className="hover:underline">Política de Privacidade</Link></li>
              <li><Link href="/termos-uso" className="hover:underline">Termos de Uso</Link></li>
              <li><Link href="/lgpd" className="hover:underline">LGPD</Link></li>
            </ul>
          </div>
        </div>
        <div className="container mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center text-xs opacity-50">
          <span>© {new Date().getFullYear()} Djair Rota Advogados. Todos os direitos reservados.</span>
          <div className="flex gap-4 mt-4 md:mt-0">
            <a href="https://instagram.com/djair.rotta" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">Instagram</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
