import { useState, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import { logAuditAction, canPerformCriticalOperation } from "@/lib/permissions";
import type { Hearing } from "@/types";
import { mockLegalCases } from "@/data/mockData";

interface HearingFormProps {
  hearing?: Hearing;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function HearingForm({ hearing, onSuccess, onCancel }: HearingFormProps) {
  const isEdit = !!hearing;
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    caseId: hearing?.caseId?.toString() || "",
    date: hearing?.date ? hearing.date.toISOString().slice(0, 16) : "",
    location: hearing?.location || "",
    notes: hearing?.notes || "",
  });

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    
    if (!canPerformCriticalOperation()) {
      toast.error("Você não tem permissão para esta operação");
      return;
    }

    setLoading(true);

    setTimeout(() => {
      const action = isEdit ? "editar" : "criar";
      const hearingId = hearing?.id || Date.now();
      const selectedCase = mockLegalCases.find(c => c.id.toString() === formData.caseId);
      
      logAuditAction(
        action,
        "audiencia",
        hearingId,
        `${selectedCase?.caseNumber} - ${formData.location}`
      );

      toast.success(`Audiência ${isEdit ? "atualizada" : "agendada"} com sucesso!`);
      setLoading(false);
      onSuccess();
    }, 1000);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <Label htmlFor="caseId">Processo *</Label>
          <Select value={formData.caseId} onValueChange={(value) => setFormData({ ...formData, caseId: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione o processo" />
            </SelectTrigger>
            <SelectContent>
              {mockLegalCases.map((legalCase) => (
                <SelectItem key={legalCase.id} value={legalCase.id.toString()}>
                  {legalCase.caseNumber} - {legalCase.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label htmlFor="date">Data e Hora *</Label>
          <Input
            id="date"
            type="datetime-local"
            value={formData.date}
            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
            required
          />
        </div>

        <div>
          <Label htmlFor="location">Local *</Label>
          <Input
            id="location"
            value={formData.location}
            onChange={(e) => setFormData({ ...formData, location: e.target.value })}
            required
            placeholder="Ex: Fórum de Mococa - Sala 3"
          />
        </div>

        <div className="col-span-2">
          <Label htmlFor="notes">Observações</Label>
          <Textarea
            id="notes"
            value={formData.notes}
            onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
            placeholder="Informações adicionais sobre a audiência..."
            rows={3}
          />
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
        <Button type="submit" disabled={loading} className="flex-1 bg-slate-800 hover:bg-slate-900">
          {loading ? "Salvando..." : isEdit ? "Atualizar" : "Agendar"}
        </Button>
      </div>
    </form>
  );
}
