import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Calendar, MapPin, Phone, FileText, Download, Edit, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { logAuditAction, hasPermission } from "@/lib/permissions";
import EventForm from "./EventForm";

interface EventDetailsModalProps {
  event: any;
  isOpen: boolean;
  onClose: () => void;
  onDelete: (eventId: string) => void;
  onUpdate: (updatedEvent: any) => void;
}

export default function EventDetailsModal({ event, isOpen, onClose, onDelete, onUpdate }: EventDetailsModalProps) {
  const [isEditing, setIsEditing] = useState(false);
  const userRole = localStorage.getItem("advogado_role") || "Advogado";
  const canEdit = hasPermission(userRole as any, "editar");
  const canDelete = hasPermission(userRole as any, "excluir");

  if (!event) return null;

  const handleDelete = () => {
    if (!canDelete) {
      toast.error("Você não tem permissão para excluir eventos");
      return;
    }

    const confirmDelete = window.confirm(
      `Tem certeza que deseja excluir o evento "${event.title}"?\n\nEsta ação não pode ser desfeita.`
    );

    if (confirmDelete) {
      logAuditAction("excluir", "tarefa", Date.now(), event.title);
      onDelete(event.id);
      toast.success("Evento excluído com sucesso");
      onClose();
    }
  };

  const handleEdit = () => {
    if (!canEdit) {
      toast.error("Você não tem permissão para editar eventos");
      return;
    }
    setIsEditing(true);
  };

  const handleUpdate = (updatedEventData: any) => {
    logAuditAction("editar", "tarefa", Date.now(), event.title);
    onUpdate({ ...event, ...updatedEventData });
    setIsEditing(false);
    toast.success("Evento atualizado com sucesso");
  };

  const handleDownloadAttachment = (attachment: any) => {
    // Simula download do anexo
    toast.success(`Download iniciado: ${attachment.name}`);
  };

  const formatDate = (date: Date) => {
    return new Date(date).toLocaleString("pt-BR", {
      day: "2-digit",
      month: "long",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const getTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      audiencia: "🏛️ Audiência",
      tarefa: "📋 Tarefa",
      atendimento: "👥 Atendimento",
      prazo: "⚠️ Prazo",
      reuniao: "📅 Reunião",
    };
    return labels[type] || "📌 Evento";
  };

  if (isEditing) {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl">Editar Evento</DialogTitle>
          </DialogHeader>
          <EventForm
            initialDate={new Date(event.start)}
            initialEvent={event}
            onSuccess={handleUpdate}
            onCancel={() => setIsEditing(false)}
          />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <DialogTitle className="font-serif text-2xl pr-8">{event.title}</DialogTitle>
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="absolute right-4 top-4"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Tipo */}
          {event.extendedProps?.type && (
            <div className="flex items-center gap-3">
              <div className="text-2xl">{getTypeLabel(event.extendedProps.type).split(" ")[0]}</div>
              <div>
                <p className="text-sm text-slate-500">Tipo</p>
                <p className="font-medium text-slate-800">{getTypeLabel(event.extendedProps.type).split(" ")[1]}</p>
              </div>
            </div>
          )}

          {/* Data e Horário */}
          <div className="flex items-start gap-3">
            <Calendar className="h-5 w-5 text-slate-500 mt-0.5" />
            <div>
              <p className="text-sm text-slate-500">Data e Horário</p>
              <p className="font-medium text-slate-800">{formatDate(event.start)}</p>
            </div>
          </div>

          {/* Local (para audiências) */}
          {event.extendedProps?.location && (
            <div className="flex items-start gap-3">
              <MapPin className="h-5 w-5 text-slate-500 mt-0.5" />
              <div>
                <p className="text-sm text-slate-500">Local</p>
                <p className="font-medium text-slate-800">{event.extendedProps.location}</p>
              </div>
            </div>
          )}

          {/* Telefone */}
          {event.extendedProps?.phone && (
            <div className="flex items-start gap-3">
              <Phone className="h-5 w-5 text-slate-500 mt-0.5" />
              <div>
                <p className="text-sm text-slate-500">Telefone de Contato</p>
                <p className="font-medium text-slate-800">{event.extendedProps.phone}</p>
              </div>
            </div>
          )}

          {/* Número do Processo (para audiências) */}
          {event.extendedProps?.caseNumber && (
            <div className="flex items-start gap-3">
              <FileText className="h-5 w-5 text-slate-500 mt-0.5" />
              <div>
                <p className="text-sm text-slate-500">Número do Processo</p>
                <p className="font-medium text-slate-800">{event.extendedProps.caseNumber}</p>
              </div>
            </div>
          )}

          {/* Observações */}
          {event.extendedProps?.description && (
            <div>
              <p className="text-sm text-slate-500 mb-2">Observações</p>
              <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
                <p className="text-slate-700 whitespace-pre-wrap">{event.extendedProps.description}</p>
              </div>
            </div>
          )}

          {/* Anexos */}
          {event.extendedProps?.attachments && event.extendedProps.attachments.length > 0 && (
            <div>
              <p className="text-sm text-slate-500 mb-3">Documentos Anexados ({event.extendedProps.attachments.length})</p>
              <div className="space-y-2">
                {event.extendedProps.attachments.map((attachment: any, index: number) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 bg-slate-50 rounded border border-slate-200 hover:bg-slate-100 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <FileText className="h-5 w-5 text-slate-500 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-slate-800 truncate">{attachment.name}</p>
                        <p className="text-xs text-slate-500">
                          {(attachment.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDownloadAttachment(attachment)}
                      className="flex-shrink-0"
                    >
                      <Download className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Ações */}
        <div className="flex gap-2 mt-6 pt-6 border-t border-slate-200">
          {canEdit && (
            <Button
              variant="outline"
              onClick={handleEdit}
              className="flex-1"
            >
              <Edit className="h-4 w-4 mr-2" />
              Editar
            </Button>
          )}
          {canDelete && (
            <Button
              variant="outline"
              onClick={handleDelete}
              className="flex-1 text-red-600 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Excluir
            </Button>
          )}
          <Button
            onClick={onClose}
            className="flex-1 bg-slate-800 hover:bg-slate-900"
          >
            Fechar
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
