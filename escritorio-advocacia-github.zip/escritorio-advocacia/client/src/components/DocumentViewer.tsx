import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  X, 
  Download, 
  ZoomIn, 
  ZoomOut, 
  ChevronLeft, 
  ChevronRight,
  Maximize2,
  FileText
} from "lucide-react";

interface DocumentViewerProps {
  documents: Array<{
    id: number;
    fileName: string;
    fileUrl: string;
    fileType: string;
  }>;
  initialIndex?: number;
  onClose: () => void;
  onDownload?: (doc: any) => void;
}

export default function DocumentViewer({ 
  documents, 
  initialIndex = 0, 
  onClose,
  onDownload 
}: DocumentViewerProps) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [zoom, setZoom] = useState(100);
  const [fullscreen, setFullscreen] = useState(false);

  const currentDoc = documents[currentIndex];
  const canGoPrev = currentIndex > 0;
  const canGoNext = currentIndex < documents.length - 1;

  const handlePrev = () => {
    if (canGoPrev) {
      setCurrentIndex(currentIndex - 1);
      setZoom(100);
    }
  };

  const handleNext = () => {
    if (canGoNext) {
      setCurrentIndex(currentIndex + 1);
      setZoom(100);
    }
  };

  const handleZoomIn = () => {
    setZoom(Math.min(zoom + 25, 200));
  };

  const handleZoomOut = () => {
    setZoom(Math.max(zoom - 25, 50));
  };

  const handleDownload = () => {
    if (onDownload) {
      onDownload(currentDoc);
    } else {
      window.open(currentDoc.fileUrl, '_blank');
    }
  };

  const toggleFullscreen = () => {
    setFullscreen(!fullscreen);
  };

  return (
    <div 
      className={`fixed inset-0 bg-black/95 z-50 flex flex-col ${fullscreen ? 'p-0' : 'p-4'}`}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      {/* Header */}
      <div className="bg-slate-900 text-white p-4 flex items-center justify-between">
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold truncate">{currentDoc.fileName}</h3>
          <p className="text-sm text-slate-400">
            {currentIndex + 1} de {documents.length} documento(s)
          </p>
        </div>

        <div className="flex items-center gap-2 ml-4">
          {/* Controles de Zoom (apenas para imagens) */}
          {currentDoc.fileType === 'image' && (
            <>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleZoomOut}
                disabled={zoom <= 50}
                className="text-white hover:bg-slate-800"
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm text-slate-300 min-w-[60px] text-center">
                {zoom}%
              </span>
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleZoomIn}
                disabled={zoom >= 200}
                className="text-white hover:bg-slate-800"
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <div className="w-px h-6 bg-slate-700 mx-2" />
            </>
          )}

          {/* Fullscreen */}
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={toggleFullscreen}
            className="text-white hover:bg-slate-800"
          >
            <Maximize2 className="h-4 w-4" />
          </Button>

          {/* Download */}
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleDownload}
            className="text-white hover:bg-slate-800"
          >
            <Download className="h-4 w-4" />
          </Button>

          {/* Fechar */}
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onClose}
            className="text-white hover:bg-slate-800"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Conteúdo */}
      <div className="flex-1 flex items-center justify-center overflow-auto relative">
        {/* Botão Anterior */}
        {canGoPrev && (
          <Button
            variant="ghost"
            size="lg"
            onClick={handlePrev}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white"
          >
            <ChevronLeft className="h-8 w-8" />
          </Button>
        )}

        {/* Visualização do Documento */}
        <div className="max-w-full max-h-full flex items-center justify-center p-4">
          {currentDoc.fileType === 'image' ? (
            <img 
              src={currentDoc.fileUrl} 
              alt={currentDoc.fileName}
              style={{ 
                maxWidth: fullscreen ? '100vw' : '90vw',
                maxHeight: fullscreen ? '100vh' : '80vh',
                width: `${zoom}%`,
                height: 'auto',
                objectFit: 'contain'
              }}
              className="transition-all duration-200"
            />
          ) : currentDoc.fileType === 'pdf' ? (
            <iframe
              src={currentDoc.fileUrl}
              className={`border-0 bg-white ${
                fullscreen 
                  ? 'w-screen h-screen' 
                  : 'w-[90vw] h-[80vh]'
              }`}
              title={currentDoc.fileName}
            />
          ) : (
            <div className="text-center py-12 bg-slate-800 rounded-lg p-8">
              <FileText className="h-16 w-16 text-slate-400 mx-auto mb-4" />
              <p className="text-white mb-4">
                Preview não disponível para este tipo de arquivo
              </p>
              <Button 
                onClick={handleDownload}
                className="bg-slate-700 hover:bg-slate-600"
              >
                <Download className="h-4 w-4 mr-2" />
                Baixar Arquivo
              </Button>
            </div>
          )}
        </div>

        {/* Botão Próximo */}
        {canGoNext && (
          <Button
            variant="ghost"
            size="lg"
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-10 bg-black/50 hover:bg-black/70 text-white"
          >
            <ChevronRight className="h-8 w-8" />
          </Button>
        )}
      </div>

      {/* Thumbnails (se houver múltiplos documentos) */}
      {documents.length > 1 && (
        <div className="bg-slate-900 p-4 overflow-x-auto">
          <div className="flex gap-2 justify-center">
            {documents.map((doc, index) => (
              <button
                key={doc.id}
                onClick={() => {
                  setCurrentIndex(index);
                  setZoom(100);
                }}
                className={`
                  flex-shrink-0 w-20 h-20 rounded border-2 overflow-hidden
                  ${index === currentIndex 
                    ? 'border-blue-500 ring-2 ring-blue-500' 
                    : 'border-slate-700 hover:border-slate-500'
                  }
                  transition-all
                `}
              >
                {doc.fileType === 'image' ? (
                  <img 
                    src={doc.fileUrl} 
                    alt={doc.fileName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-800 flex items-center justify-center">
                    <FileText className="h-8 w-8 text-slate-400" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Navegação por teclado */}
      <div className="hidden">
        {/* Listeners de teclado serão adicionados via useEffect se necessário */}
      </div>
    </div>
  );
}
