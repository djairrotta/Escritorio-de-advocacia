import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, X, FileText } from "lucide-react";
import { toast } from "sonner";
import { mockLegalCases } from "@/data/mockData";
import { logAuditAction, canAssignTasks, getCurrentUserId } from "@/lib/permissions";
import { createAutoReminder } from "@/lib/reminders";

// Mock de advogados (em produção, vir do banco)
const mockAdvogados = [
  { id: 1, name: "Dr. Djair Rota" },
  { id: 2, name: "Dra. Maria Silva" },
  { id: 3, name: "Dr. João Santos" },
];

interface EventFormProps {
  initialDate?: Date;
  initialEvent?: any;
  onSuccess: (event: any) => void;
  onCancel: () => void;
}

export default function EventForm({ initialDate, initialEvent, onSuccess, onCancel }: EventFormProps) {
  const [formData, setFormData] = useState({
    title: initialEvent?.title?.replace(/^[🏛️📋👥⚠️📅]\s*/, "") || "",
    type: (initialEvent?.extendedProps?.type || "audiencia") as "audiencia" | "tarefa" | "atendimento" | "prazo" | "reuniao",
    date: initialEvent?.start ? new Date(initialEvent.start).toISOString().slice(0, 16) : (initialDate ? initialDate.toISOString().slice(0, 16) : ""),
    phone: initialEvent?.extendedProps?.phone || "",
    description: initialEvent?.extendedProps?.description || "",
    linkedCaseId: initialEvent?.extendedProps?.linkedCaseId || "",
    assignedTo: initialEvent?.extendedProps?.assignedTo?.toString() || getCurrentUserId().toString(),
  });
  const [attachments, setAttachments] = useState<File[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setAttachments([...attachments, ...newFiles]);
      toast.success(`${newFiles.length} arquivo(s) adicionado(s)`);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index));
    toast.info("Arquivo removido");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.title || !formData.date) {
      toast.error("Preencha o título e a data do evento");
      return;
    }

    const newEvent = {
      id: `event-${Date.now()}`,
      title: `${getEventIcon(formData.type)} ${formData.title}`,
      start: new Date(formData.date),
      backgroundColor: getEventColor(formData.type).bg,
      borderColor: getEventColor(formData.type).border,
      extendedProps: {
        type: formData.type,
        phone: formData.phone,
        description: formData.description,
        linkedCaseId: formData.linkedCaseId,
        attachments: attachments.map(f => ({
          name: f.name,
          size: f.size,
          type: f.type,
        })),
      },
    };

    // Log de auditoria
    logAuditAction("criar", "tarefa", Date.now(), formData.title);

    // Criar lembrete automático (24h antes)
    createAutoReminder(newEvent.id, formData.title, new Date(formData.date));

    onSuccess(newEvent);
    toast.success("Evento criado com sucesso!");
  };

  const getEventIcon = (type: string) => {
    const icons: Record<string, string> = {
      audiencia: "🏛️",
      tarefa: "📋",
      atendimento: "👥",
      prazo: "⚠️",
      reuniao: "📅",
    };
    return icons[type] || "📌";
  };

  const getEventColor = (type: string) => {
    const colors: Record<string, { bg: string; border: string }> = {
      audiencia: { bg: "#3b82f6", border: "#2563eb" },
      tarefa: { bg: "#f59e0b", border: "#d97706" },
      atendimento: { bg: "#8b5cf6", border: "#7c3aed" },
      prazo: { bg: "#ef4444", border: "#dc2626" },
      reuniao: { bg: "#10b981", border: "#059669" },
    };
    return colors[type] || { bg: "#6b7280", border: "#4b5563" };
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="title">Título do Evento *</Label>
        <Input
          id="title"
          value={formData.title}
          onChange={(e) => setFormData({ ...formData, title: e.target.value })}
          placeholder="Ex: Reunião com cliente João Silva"
          required
        />
      </div>

      <div>
        <Label htmlFor="type">Tipo de Evento *</Label>
        <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value as typeof formData.type })}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="audiencia">🏛️ Audiência</SelectItem>
            <SelectItem value="tarefa">📋 Tarefa</SelectItem>
            <SelectItem value="atendimento">👥 Atendimento</SelectItem>
            <SelectItem value="prazo">⚠️ Prazo</SelectItem>
            <SelectItem value="reuniao">📅 Reunião</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="date">Data e Horário *</Label>
        <Input
          id="date"
          type="datetime-local"
          value={formData.date}
          onChange={(e) => setFormData({ ...formData, date: e.target.value })}
          required
        />
      </div>

      <div>
        <Label htmlFor="phone">Telefone de Contato</Label>
        <Input
          id="phone"
          type="tel"
          value={formData.phone}
          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
          placeholder="(16) 99999-9999"
        />
      </div>

      <div>
        <Label htmlFor="linkedCase">Processo Vinculado (Opcional)</Label>
        <Select value={formData.linkedCaseId || "none"} onValueChange={(value) => setFormData({ ...formData, linkedCaseId: value === "none" ? "" : value })}>
          <SelectTrigger>
            <SelectValue placeholder="Selecione um processo" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">Nenhum</SelectItem>
            {mockLegalCases.map((legalCase) => (
              <SelectItem key={legalCase.id} value={legalCase.id.toString()}>
                {legalCase.caseNumber} - {legalCase.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {canAssignTasks() && (
        <div>
          <Label htmlFor="assignedTo">Atribuir a Advogado</Label>
          <Select value={formData.assignedTo} onValueChange={(value) => setFormData({ ...formData, assignedTo: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Selecione um advogado" />
            </SelectTrigger>
            <SelectContent>
              {mockAdvogados.map((advogado) => (
                <SelectItem key={advogado.id} value={advogado.id.toString()}>
                  {advogado.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      <div>
        <Label htmlFor="description">Observações</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Detalhes adicionais sobre o evento..."
          rows={3}
        />
      </div>

      <div>
        <Label>Anexar Documentos</Label>
        <div className="mt-2">
          <label
            htmlFor="file-upload"
            className="flex items-center justify-center gap-2 p-4 border-2 border-dashed border-slate-300 rounded-lg hover:border-slate-400 cursor-pointer transition-colors"
          >
            <Upload className="h-5 w-5 text-slate-500" />
            <span className="text-sm text-slate-600">Clique para selecionar arquivos</span>
            <input
              id="file-upload"
              type="file"
              multiple
              onChange={handleFileChange}
              className="hidden"
              accept=".pdf,.doc,.docx,.jpg,.jpeg,.png"
            />
          </label>

          {attachments.length > 0 && (
            <div className="mt-3 space-y-2">
              {attachments.map((file, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-slate-50 rounded border border-slate-200"
                >
                  <div className="flex items-center gap-2 flex-1 min-w-0">
                    <FileText className="h-4 w-4 text-slate-500 flex-shrink-0" />
                    <span className="text-sm text-slate-700 truncate">{file.name}</span>
                    <span className="text-xs text-slate-500 flex-shrink-0">
                      ({(file.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAttachment(index)}
                    className="flex-shrink-0"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex gap-2 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
        <Button type="submit" className="flex-1 bg-slate-800 hover:bg-slate-900">
          Criar Evento
        </Button>
      </div>
    </form>
  );
}
