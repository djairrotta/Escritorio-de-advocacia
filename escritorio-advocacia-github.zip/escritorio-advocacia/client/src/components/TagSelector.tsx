import { useState } from "react";
import { X, Plus, Tag as TagIcon } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { predefinedTags, getTagConfig } from "@/lib/documentTags";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";

interface TagSelectorProps {
  selectedTags: string[];
  onTagsChange: (tags: string[]) => void;
  placeholder?: string;
}

export default function TagSelector({ selectedTags, onTagsChange, placeholder }: TagSelectorProps) {
  const [open, setOpen] = useState(false);
  const [customTag, setCustomTag] = useState("");

  const handleAddTag = (tagName: string) => {
    if (!selectedTags.includes(tagName)) {
      onTagsChange([...selectedTags, tagName]);
    }
    setOpen(false);
  };

  const handleAddCustomTag = () => {
    if (customTag.trim() && !selectedTags.includes(customTag.trim())) {
      onTagsChange([...selectedTags, customTag.trim()]);
      setCustomTag("");
      setOpen(false);
    }
  };

  const handleRemoveTag = (tagToRemove: string) => {
    onTagsChange(selectedTags.filter(tag => tag !== tagToRemove));
  };

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2 min-h-[40px] p-2 border border-slate-300 rounded-md bg-white">
        {selectedTags.length === 0 && (
          <span className="text-sm text-slate-400">{placeholder || "Nenhuma tag selecionada"}</span>
        )}
        
        {selectedTags.map((tag) => {
          const config = getTagConfig(tag);
          return (
            <span
              key={tag}
              className={`
                inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-medium border
                ${config.color} ${config.bgColor} ${config.borderColor}
              `}
            >
              {tag}
              <button
                onClick={() => handleRemoveTag(tag)}
                className="hover:opacity-70 transition-opacity"
                type="button"
              >
                <X className="h-3 w-3" />
              </button>
            </span>
          );
        })}
      </div>

      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button variant="outline" size="sm" className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Adicionar Tag
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-80" align="start">
          <div className="space-y-3">
            <div>
              <p className="text-sm font-medium text-slate-700 mb-2">Tags Predefinidas</p>
              <div className="flex flex-wrap gap-2">
                {predefinedTags.map((tagConfig) => (
                  <button
                    key={tagConfig.name}
                    onClick={() => handleAddTag(tagConfig.name)}
                    disabled={selectedTags.includes(tagConfig.name)}
                    className={`
                      px-2 py-1 rounded-md text-xs font-medium border transition-all
                      ${tagConfig.color} ${tagConfig.bgColor} ${tagConfig.borderColor}
                      ${selectedTags.includes(tagConfig.name) 
                        ? 'opacity-50 cursor-not-allowed' 
                        : 'hover:opacity-80 cursor-pointer'
                      }
                    `}
                  >
                    {tagConfig.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="border-t border-slate-200 pt-3">
              <p className="text-sm font-medium text-slate-700 mb-2">Tag Customizada</p>
              <div className="flex gap-2">
                <Input
                  placeholder="Digite uma tag..."
                  value={customTag}
                  onChange={(e) => setCustomTag(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddCustomTag();
                    }
                  }}
                  className="flex-1"
                />
                <Button
                  onClick={handleAddCustomTag}
                  disabled={!customTag.trim()}
                  size="sm"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </PopoverContent>
      </Popover>
    </div>
  );
}
