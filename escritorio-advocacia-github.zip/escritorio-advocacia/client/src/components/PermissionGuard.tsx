import { ReactNode } from "react";
import { canPerformCriticalOperation } from "@/lib/permissions";
import { AlertCircle } from "lucide-react";
import { Card } from "@/components/ui/card";

interface PermissionGuardProps {
  children: ReactNode;
  fallback?: ReactNode;
}

export default function PermissionGuard({ children, fallback }: PermissionGuardProps) {
  if (!canPerformCriticalOperation()) {
    return (
      fallback || (
        <Card className="p-8 text-center border-red-200 bg-red-50">
          <AlertCircle className="h-12 w-12 text-red-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-900 mb-2">Acesso Negado</h3>
          <p className="text-red-700">
            Você não possui permissões para realizar esta operação.
            <br />
            Apenas usuários <strong>Master</strong> e <strong>Moderador</strong> podem criar, editar ou excluir registros.
          </p>
        </Card>
      )
    );
  }

  return <>{children}</>;
}
