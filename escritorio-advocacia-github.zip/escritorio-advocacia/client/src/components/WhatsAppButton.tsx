import { MessageCircle } from "lucide-react";
import { useLocation } from "wouter";
import { trackEvent } from "./GoogleAnalytics";

export default function WhatsAppButton() {
  const [location] = useLocation();

  // Ocultar botão nas rotas de dashboard de advogados e clientes
  const isPrivateRoute = location.startsWith('/advogados') || location.startsWith('/cliente');

  if (isPrivateRoute) {
    return null;
  }

  return (
    <a
      href="https://wa.me/551936564903"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-lg hover:bg-[#128C7E] transition-all duration-300 hover:scale-110 flex items-center justify-center group"
      aria-label="Fale conosco no WhatsApp"
      onClick={() => trackEvent('whatsapp_click', { location: 'floating_button' })}
    >
      <MessageCircle className="h-8 w-8" />
      <span className="absolute right-full mr-3 bg-white text-gray-800 px-3 py-1 rounded text-sm font-medium opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-sm pointer-events-none">
        Fale Conosco
      </span>
    </a>
  );
}
