import { useState, FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { logAuditAction, canPerformCriticalOperation } from "@/lib/permissions";
import type { Client } from "@/types";
import { Upload, X, FileText } from "lucide-react";
import { Card } from "@/components/ui/card";
import TagSelector from "@/components/TagSelector";

interface ClientFormProps {
  client?: Client;
  onSuccess: () => void;
  onCancel: () => void;
}

export default function ClientForm({ client, onSuccess, onCancel }: ClientFormProps) {
  const isEdit = !!client;
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: client?.name || "",
    cpf: client?.cpf || "",
    rg: client?.rg || "",
    birthDate: client?.birthDate || "",
    email: client?.email || "",
    phone: client?.phone || "",
    address: client?.address || "",
  });

  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [documentTags, setDocumentTags] = useState<string[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    const validFiles = files.filter(file => {
      // Tipos de arquivo permitidos: documentos, imagens, vídeos e áudios
      const allowedTypes = [
        // Documentos
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        // Imagens
        'image/jpeg',
        'image/jpg',
        'image/png',
        'image/gif',
        'image/webp',
        // Vídeos
        'video/mp4',
        'video/avi',
        'video/quicktime', // .mov
        'video/x-matroska', // .mkv
        'video/webm',
        'video/x-msvideo',
        // Áudios
        'audio/mpeg', // .mp3
        'audio/wav',
        'audio/x-wav',
        'audio/mp4', // .m4a
        'audio/ogg',
        'audio/webm'
      ];
      
      const isValidType = allowedTypes.includes(file.type);
      
      if (!isValidType) {
        toast.error(`${file.name}: Tipo de arquivo não permitido`);
        return false;
      }
      
      return true;
    });
    
    setUploadedFiles(prev => [...prev, ...validFiles]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    
    if (!canPerformCriticalOperation()) {
      toast.error("Você não tem permissão para esta operação");
      return;
    }

    setLoading(true);

    try {
      const action = isEdit ? "editar" : "criar";
      const clientId = client?.id || Date.now();
      
      // Upload de documentos para S3 (se houver)
      if (uploadedFiles.length > 0) {
        toast.info(`Enviando ${uploadedFiles.length} documento(s)...`);
        
        for (const file of uploadedFiles) {
          const formData = new FormData();
          formData.append('file', file);
          formData.append('clientId', clientId.toString());
          
          try {
            const response = await fetch('/api/upload', {
              method: 'POST',
              body: formData,
            });
            
            if (!response.ok) {
              throw new Error(`Falha ao enviar ${file.name}`);
            }
            
            const data = await response.json();
            console.log(`Arquivo ${file.name} enviado:`, data.fileUrl);
            
            // Salvar referência do documento no localStorage (simulação)
            const documents = JSON.parse(localStorage.getItem('documents') || '[]');
            documents.push({
              id: Date.now() + Math.random(),
              clientId: clientId,
              clienteName: formData.name,
              fileName: file.name,
              fileUrl: data.fileUrl,
              fileSize: `${(file.size / 1024).toFixed(2)} KB`,
              uploadDate: new Date().toISOString(),
              uploadedBy: localStorage.getItem('advogado_name') || 'Sistema',
              extractedText: data.extractedText || null, // Texto extraído via OCR
              tags: documentTags, // Tags selecionadas
            });
            localStorage.setItem('documents', JSON.stringify(documents));
          } catch (error) {
            console.error(`Erro ao enviar ${file.name}:`, error);
            toast.error(`Erro ao enviar ${file.name}`);
          }
        }
        
        toast.success(`${uploadedFiles.length} documento(s) enviado(s) com sucesso!`);
      }
      
      logAuditAction(
        action,
        "cliente",
        clientId,
        `${formData.name} (CPF: ${formData.cpf}${formData.rg ? ', RG: ' + formData.rg : ''})`
      );

      toast.success(`Cliente ${isEdit ? "atualizado" : "cadastrado"} com sucesso!`);
      setLoading(false);
      onSuccess();
    } catch (error) {
      console.error('Erro ao salvar cliente:', error);
      toast.error('Erro ao salvar cliente');
      setLoading(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4 mt-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="col-span-2">
          <Label htmlFor="name">Nome Completo *</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
            placeholder="João Silva Oliveira"
          />
        </div>

        <div>
          <Label htmlFor="cpf">CPF *</Label>
          <Input
            id="cpf"
            value={formData.cpf}
            onChange={(e) => setFormData({ ...formData, cpf: e.target.value })}
            required
            placeholder="000.000.000-00"
          />
        </div>

        <div>
          <Label htmlFor="rg">RG</Label>
          <Input
            id="rg"
            value={formData.rg}
            onChange={(e) => setFormData({ ...formData, rg: e.target.value })}
            placeholder="00.000.000-0"
          />
        </div>

        <div>
          <Label htmlFor="birthDate">Data de Aniversário</Label>
          <Input
            id="birthDate"
            type="date"
            value={formData.birthDate}
            onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
          />
        </div>

        <div>
          <Label htmlFor="phone">Telefone</Label>
          <Input
            id="phone"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="(16) 99999-9999"
          />
        </div>

        <div className="col-span-2">
          <Label htmlFor="email">E-mail</Label>
          <Input
            id="email"
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="cliente@email.com"
          />
        </div>

        <div className="col-span-2">
          <Label htmlFor="address">Endereço</Label>
          <Textarea
            id="address"
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            placeholder="Rua, número, bairro, cidade - UF"
            rows={3}
          />
        </div>

        {/* Upload de Documentos */}
        <div className="col-span-2">
          <Label>Documentos (Opcional)</Label>
          <Card className="p-4 border-2 border-dashed border-slate-300 hover:border-slate-400 transition-colors">
            <div className="flex flex-col items-center justify-center gap-3">
              <Upload className="h-8 w-8 text-slate-400" />
              <div className="text-center">
                <p className="text-sm text-slate-600 mb-1">
                  Arraste arquivos ou clique para selecionar
                </p>
                <p className="text-xs text-slate-500">
                  PDF, JPG, PNG, DOC, DOCX (máx. 10MB cada)
                </p>
              </div>
              <Input
                type="file"
                multiple
                accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                onChange={handleFileChange}
                className="hidden"
                id="file-upload"
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => document.getElementById('file-upload')?.click()}
              >
                Selecionar Arquivos
              </Button>
            </div>
          </Card>

          {/* Seletor de Tags para Documentos */}
          {uploadedFiles.length > 0 && (
            <div className="mt-3">
              <Label className="text-sm font-semibold mb-2">Tags para os Documentos</Label>
              <TagSelector 
                selectedTags={documentTags}
                onTagsChange={setDocumentTags}
                placeholder="Adicione tags para organizar os documentos"
              />
            </div>
          )}
          
          {/* Lista de arquivos selecionados */}
          {uploadedFiles.length > 0 && (
            <div className="mt-3 space-y-2">
              <Label className="text-sm font-semibold">Arquivos Selecionados ({uploadedFiles.length})</Label>
              {uploadedFiles.map((file, index) => (
                <Card key={index} className="p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText className="h-5 w-5 text-slate-600" />
                    <div>
                      <p className="text-sm font-medium text-slate-800">{file.name}</p>
                      <p className="text-xs text-slate-500">
                        {(file.size / 1024).toFixed(2)} KB
                      </p>
                    </div>
                  </div>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFile(index)}
                  >
                    <X className="h-4 w-4 text-red-500" />
                  </Button>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel} className="flex-1">
          Cancelar
        </Button>
        <Button type="submit" disabled={loading} className="flex-1 bg-slate-800 hover:bg-slate-900">
          {loading ? "Salvando..." : isEdit ? "Atualizar" : "Cadastrar"}
        </Button>
      </div>
    </form>
  );
}
