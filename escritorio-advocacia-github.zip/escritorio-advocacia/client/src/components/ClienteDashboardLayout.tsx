import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { FileText, Calendar, LogOut, Menu, X, User, Bell, MessageCircle } from "lucide-react";
import { toast } from "sonner";

interface ClienteData {
  id: number;
  name: string;
  email: string;
  cpf: string;
  phone: string;
}

export default function ClienteDashboardLayout({ children }: { children: React.ReactNode }) {
  const [location, setLocation] = useLocation();
  const [cliente, setCliente] = useState<ClienteData | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    const clienteAuth = localStorage.getItem("clienteAuth");
    if (!clienteAuth) {
      setLocation("/cliente");
      return;
    }
    setCliente(JSON.parse(clienteAuth));
  }, [setLocation]);

  const handleLogout = () => {
    localStorage.removeItem("clienteAuth");
    toast.success("Logout realizado com sucesso");
    setLocation("/cliente");
  };

  const menuItems = [
    { icon: FileText, label: "Meus Processos", path: "/cliente/dashboard" },
    { icon: Calendar, label: "Agendamentos", path: "/cliente/agendamentos" },
    { icon: MessageCircle, label: "Mensagens", path: "/cliente/mensagens" },
  ];

  if (!cliente) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-slate-800 mx-auto mb-4"></div>
          <p className="text-slate-600">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                className="lg:hidden"
                onClick={() => setSidebarOpen(!sidebarOpen)}
              >
                {sidebarOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </Button>
              <Link href="/cliente/dashboard">
                <img 
                  src="/images/logo-transparent.png" 
                  alt="Djair Rota Advogados" 
                  className="h-10 w-auto cursor-pointer"
                />
              </Link>
            </div>

            {/* User Menu */}
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" className="hidden sm:flex">
                <Bell className="h-5 w-5" />
              </Button>
              <div className="hidden sm:flex items-center gap-3">
                <div className="text-right">
                  <p className="text-sm font-semibold text-slate-900">{cliente.name}</p>
                  <p className="text-xs text-slate-500">{cliente.email}</p>
                </div>
                <div className="w-10 h-10 rounded-full bg-slate-200 flex items-center justify-center">
                  <User className="h-5 w-5 text-slate-600" />
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={handleLogout}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside
          className={`
            fixed lg:static inset-y-0 left-0 z-30 w-64 bg-white border-r border-slate-200 
            transform transition-transform duration-200 ease-in-out lg:translate-x-0
            ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}
            mt-16 lg:mt-0
          `}
        >
          <nav className="p-4 space-y-2">
            {menuItems.map((item) => {
              const isActive = location === item.path;
              return (
                <Link key={item.path} href={item.path}>
                  <Button
                    variant={isActive ? "default" : "ghost"}
                    className={`w-full justify-start ${
                      isActive
                        ? "bg-slate-800 text-white hover:bg-slate-900"
                        : "text-slate-700 hover:bg-slate-100"
                    }`}
                    onClick={() => setSidebarOpen(false)}
                  >
                    <item.icon className="mr-3 h-5 w-5" />
                    {item.label}
                  </Button>
                </Link>
              );
            })}
          </nav>

          {/* Help Section */}
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-slate-200 bg-slate-50">
            <p className="text-xs text-slate-600 mb-2">Precisa de ajuda?</p>
            <a
              href="https://wa.me/551936564903"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="outline" size="sm" className="w-full text-xs">
                Falar com Advogado
              </Button>
            </a>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 lg:ml-0">
          {children}
        </main>
      </div>

      {/* Overlay para mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
