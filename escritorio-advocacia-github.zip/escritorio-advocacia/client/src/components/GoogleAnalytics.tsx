import { useEffect } from "react";
import { useLocation } from "wouter";

declare global {
  interface Window {
    dataLayer: any[];
    gtag: (...args: any[]) => void;
  }
}

// Default ID placeholder - user should replace this
const GA_MEASUREMENT_ID = "G-XXXXXXXXXX";

export const trackEvent = (eventName: string, eventParams?: Record<string, any>) => {
  if (window.gtag) {
    window.gtag('event', eventName, eventParams);
  } else {
    console.log(`[GA Event] ${eventName}`, eventParams);
  }
};

export default function GoogleAnalytics() {
  const [location] = useLocation();

  useEffect(() => {
    // Initialize dataLayer
    window.dataLayer = window.dataLayer || [];
    function gtag(...args: any[]) {
      window.dataLayer.push(args);
    }
    window.gtag = gtag; // Ensure global availability
    
    gtag('js', new Date());
    gtag('config', GA_MEASUREMENT_ID);

    // Load the script
    const script = document.createElement("script");
    script.src = `https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`;
    script.async = true;
    document.head.appendChild(script);

    return () => {
      // We don't remove the script to avoid reloading it unnecessarily
      // document.head.removeChild(script);
    };
  }, []);

  useEffect(() => {
    // Track page views on route change
    if (window.gtag) {
      window.gtag('config', GA_MEASUREMENT_ID, {
        page_path: location,
      });
    }
  }, [location]);

  return null;
}
