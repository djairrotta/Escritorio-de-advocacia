export interface Lawyer {
  id: string;
  name: string;
  role: string;
  oab: string;
  specialties: string[];
  bio: string;
  education: string[];
  languages: string[];
  email: string;
  linkedin?: string;
  image: string;
}

export const lawyers: Lawyer[] = [
  {
    id: "djair-rota",
    name: "Dr. Djair Rota",
    role: "Sócio Fundador",
    oab: "OAB/SP 123.456",
    specialties: ["Direito Empresarial", "Direito Tributário", "Gestão de Crise"],
    bio: "Com mais de 30 anos de experiência, Dr. Djair Rota é referência em advocacia empresarial e tributária. Fundou o escritório com a visão de oferecer um atendimento personalizado e estratégico, focado em resultados concretos para seus clientes. Sua atuação é marcada pela ética, combatividade e profundo conhecimento técnico.",
    education: [
      "Doutorado em Direito Tributário pela USP",
      "Mestrado em Direito Empresarial pela PUC-SP",
      "Bacharel em Direito pela USP"
    ],
    languages: ["Português", "Inglês", "Espanhol"],
    email: "djair@djairrota.adv.br",
    image: "/images/djair-rota.jpg"
  },
  {
    id: "ana-souza",
    name: "Dra. Ana Souza",
    role: "Advogada Sênior - Cível",
    oab: "OAB/SP 234.567",
    specialties: ["Direito Civil", "Contratos", "Responsabilidade Civil"],
    bio: "Especialista em contencioso cível estratégico, Dra. Ana possui vasta experiência em resolução de conflitos complexos e negociações de alto nível. Atua com foco na prevenção de litígios e na proteção patrimonial dos clientes.",
    education: [
      "Pós-graduação em Processo Civil pela PUC-SP",
      "Bacharel em Direito pela Mackenzie"
    ],
    languages: ["Português", "Inglês"],
    email: "ana.souza@djairrota.adv.br",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "carlos-lima",
    name: "Dr. Carlos Lima",
    role: "Advogado Sênior - Trabalhista",
    oab: "OAB/SP 345.678",
    specialties: ["Direito do Trabalho", "Compliance Trabalhista", "Negociação Sindical"],
    bio: "Com foco na defesa patronal, Dr. Carlos auxilia empresas na gestão de riscos trabalhistas e na implementação de políticas de compliance. Sua atuação preventiva tem gerado economia significativa para os clientes do escritório.",
    education: [
      "Especialização em Direito do Trabalho pela FGV",
      "Bacharel em Direito pela USP"
    ],
    languages: ["Português", "Espanhol"],
    email: "carlos.lima@djairrota.adv.br",
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "beatriz-silva",
    name: "Dra. Beatriz Silva",
    role: "Advogada Pleno - Família",
    oab: "OAB/SP 456.789",
    specialties: ["Direito de Família", "Sucessões", "Planejamento Sucessório"],
    bio: "Dra. Beatriz atua com sensibilidade e técnica em casos de família e sucessões. Seu trabalho envolve desde divórcios e inventários até complexos planejamentos sucessórios para grupos familiares.",
    education: [
      "Mestrado em Direito de Família pela PUC-SP",
      "Bacharel em Direito pela FMU"
    ],
    languages: ["Português", "Francês"],
    email: "beatriz.silva@djairrota.adv.br",
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "pedro-santos",
    name: "Dr. Pedro Santos",
    role: "Advogado Pleno - Criminal",
    oab: "OAB/SP 567.890",
    specialties: ["Direito Penal Econômico", "Compliance Criminal", "Investigações Internas"],
    bio: "Especialista em Direito Penal Econômico, Dr. Pedro atua na defesa de empresas e executivos em inquéritos e processos criminais. Sua prática inclui também a condução de investigações internas e programas de compliance.",
    education: [
      "Especialização em Direito Penal Econômico pela FGV",
      "Bacharel em Direito pela PUC-Campinas"
    ],
    languages: ["Português", "Inglês"],
    email: "pedro.santos@djairrota.adv.br",
    image: "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "fernanda-oliveira",
    name: "Dra. Fernanda Oliveira",
    role: "Advogada Júnior - Empresarial",
    oab: "OAB/SP 678.901",
    specialties: ["Contratos Empresariais", "Societário", "Startups"],
    bio: "Dra. Fernanda foca sua atuação no direito societário e contratual, assessorando empresas em suas operações diárias e em transações de M&A. Possui experiência no ecossistema de inovação e startups.",
    education: [
      "LL.M. em Direito Societário pelo Insper",
      "Bacharel em Direito pela USP"
    ],
    languages: ["Português", "Inglês"],
    email: "fernanda.oliveira@djairrota.adv.br",
    image: "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  },
  {
    id: "lucas-pereira",
    name: "Dr. Lucas Pereira",
    role: "Advogado Júnior - Tributário",
    oab: "OAB/SP 789.012",
    specialties: ["Contencioso Tributário", "Consultoria Fiscal", "Planejamento Tributário"],
    bio: "Dr. Lucas dedica-se ao direito tributário, auxiliando clientes na interpretação da legislação fiscal e na defesa contra autuações. Seu trabalho busca sempre a eficiência tributária dentro da legalidade.",
    education: [
      "Especialização em Direito Tributário pelo IBET",
      "Bacharel em Direito pela Mackenzie"
    ],
    languages: ["Português", "Inglês"],
    email: "lucas.pereira@djairrota.adv.br",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
  }
];
