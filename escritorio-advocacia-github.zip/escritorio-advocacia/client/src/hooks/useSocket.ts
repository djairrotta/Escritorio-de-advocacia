import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";

interface Message {
  id: number;
  senderType: "client" | "user";
  senderId: number;
  senderName: string;
  recipientId: number;
  recipientName: string;
  message: string;
  attachments?: string[];
  createdAt: Date;
  isRead: boolean;
}

interface UseSocketReturn {
  socket: Socket | null;
  connected: boolean;
  sendMessage: (message: Omit<Message, "id" | "createdAt" | "isRead">) => void;
  markAsRead: (messageId: number) => void;
}

export function useSocket(userId: number, userType: "client" | "user"): UseSocketReturn {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    // Conectar ao servidor WebSocket
    const socketUrl = window.location.origin;
    const socket = io(socketUrl, {
      transports: ["websocket", "polling"],
    });

    socketRef.current = socket;

    socket.on("connect", () => {
      console.log("✅ Conectado ao WebSocket");
      setConnected(true);
      
      // Registrar usuário
      socket.emit("register", { userId, userType });
    });

    socket.on("disconnect", () => {
      console.log("❌ Desconectado do WebSocket");
      setConnected(false);
    });

    socket.on("connect_error", (error) => {
      console.error("Erro de conexão:", error);
      setConnected(false);
    });

    return () => {
      socket.disconnect();
    };
  }, [userId, userType]);

  const sendMessage = (message: Omit<Message, "id" | "createdAt" | "isRead">) => {
    if (socketRef.current && connected) {
      socketRef.current.emit("send_message", {
        ...message,
        isRead: false,
      });
    } else {
      console.error("Socket não conectado");
    }
  };

  const markAsRead = (messageId: number) => {
    if (socketRef.current && connected) {
      socketRef.current.emit("mark_read", { messageId });
    }
  };

  return {
    socket: socketRef.current,
    connected,
    sendMessage,
    markAsRead,
  };
}
