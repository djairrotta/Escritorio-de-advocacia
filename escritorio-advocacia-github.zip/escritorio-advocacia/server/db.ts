import { drizzle } from "drizzle-orm/mysql2";
import mysql from "mysql2/promise";
import * as schema from "../drizzle/schema";
import { eq, desc } from "drizzle-orm";

// Criar pool de conexões
const connection = mysql.createPool(process.env.DATABASE_URL!);
export const db = drizzle(connection, { schema, mode: "default" });

// ===== USERS =====
export async function getUserByEmail(email: string) {
  const [user] = await db.select().from(schema.users).where(eq(schema.users.email, email)).limit(1);
  return user;
}

export async function createUser(data: schema.NewUser) {
  const [result] = await db.insert(schema.users).values(data);
  return result.insertId;
}

// ===== CLIENTS =====
export async function getClientByEmail(email: string) {
  const [client] = await db.select().from(schema.clients).where(eq(schema.clients.email, email)).limit(1);
  return client;
}

export async function getAllClients() {
  return await db.select().from(schema.clients).where(eq(schema.clients.active, true)).orderBy(schema.clients.name);
}

export async function createClient(data: schema.NewClient) {
  const [result] = await db.insert(schema.clients).values(data);
  return result.insertId;
}

// ===== LEGAL CASES =====
export async function getAllLegalCases() {
  return await db.select().from(schema.legalCases).orderBy(desc(schema.legalCases.createdAt));
}

export async function getLegalCasesByClientId(clientId: number) {
  return await db.select().from(schema.legalCases).where(eq(schema.legalCases.clientId, clientId));
}

export async function createLegalCase(data: schema.NewLegalCase) {
  const [result] = await db.insert(schema.legalCases).values(data);
  return result.insertId;
}

// ===== CALENDAR EVENTS =====
export async function getAllCalendarEvents() {
  return await db.select().from(schema.calendarEvents).orderBy(schema.calendarEvents.startDate);
}

export async function createCalendarEvent(data: schema.NewCalendarEvent) {
  const [result] = await db.insert(schema.calendarEvents).values(data);
  return result.insertId;
}

// ===== NOTIFICATIONS =====
export async function createNotification(data: schema.NewNotification) {
  const [result] = await db.insert(schema.notifications).values(data);
  return result.insertId;
}

export async function getAllNotifications() {
  return await db.select().from(schema.notifications).orderBy(desc(schema.notifications.createdAt)).limit(100);
}

export async function updateNotificationStatus(id: number, status: "sent" | "failed", errorMessage?: string) {
  await db.update(schema.notifications).set({
    status,
    sentAt: status === "sent" ? new Date() : undefined,
    errorMessage,
  }).where(eq(schema.notifications.id, id));
}

// ===== AUDIT LOGS =====
export async function createAuditLog(data: schema.NewAuditLog) {
  const [result] = await db.insert(schema.auditLogs).values(data);
  return result.insertId;
}

// ===== MESSAGES =====
export async function getMessagesBetween(senderId: number, senderType: "client" | "user", recipientId: number, recipientType: "client" | "user") {
  return await db.select().from(schema.messages).where(
    eq(schema.messages.senderId, senderId)
  ).orderBy(schema.messages.createdAt);
}

export async function getMessagesForUser(userId: number, userType: "client" | "user") {
  return await db.select().from(schema.messages).where(
    eq(schema.messages.recipientId, userId)
  ).orderBy(desc(schema.messages.createdAt));
}

export async function createMessage(data: schema.NewMessage) {
  const [result] = await db.insert(schema.messages).values(data);
  return result.insertId;
}

export async function markMessageAsRead(id: number) {
  await db.update(schema.messages).set({ isRead: true }).where(eq(schema.messages.id, id));
}

export async function getUnreadCount(userId: number, userType: "client" | "user") {
  const messages = await db.select().from(schema.messages).where(
    eq(schema.messages.recipientId, userId)
  );
  return messages.filter(m => !m.isRead).length;
}
