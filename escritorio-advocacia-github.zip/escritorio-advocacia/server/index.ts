import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import path from "path";
import { fileURLToPath } from "url";
import multer from "multer";
import * as db from "./db";
import { storagePut } from "./storage";
import { extractTextFromDocument } from "./ocr";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  app.use(express.json());
  const server = createServer(app);
  
  // Configurar Socket.io
  const io = new Server(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });
  
  // Configurar multer para upload
  const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB
  });

  // Socket.io - Gerenciamento de mensagens em tempo real
  const connectedUsers = new Map<string, { userId: number; userType: "client" | "user" }>();
  
  io.on("connection", (socket) => {
    console.log("Cliente conectado:", socket.id);
    
    // Registrar usuário
    socket.on("register", ({ userId, userType }: { userId: number; userType: "client" | "user" }) => {
      connectedUsers.set(socket.id, { userId, userType });
      console.log(`Usuário registrado: ${userType} #${userId}`);
    });
    
    // Enviar mensagem
    socket.on("send_message", async (data: any) => {
      try {
        const messageId = await db.createMessage(data);
        const message = { ...data, id: messageId, createdAt: new Date() };
        
        // Broadcast para todos os clientes
        io.emit("new_message", message);
        console.log("Mensagem enviada:", messageId);
      } catch (error) {
        console.error("Erro ao enviar mensagem:", error);
        socket.emit("message_error", { error: "Falha ao enviar mensagem" });
      }
    });
    
    // Marcar mensagem como lida
    socket.on("mark_read", async ({ messageId }: { messageId: number }) => {
      try {
        await db.markMessageAsRead(messageId);
        io.emit("message_read", { messageId });
      } catch (error) {
        console.error("Erro ao marcar como lida:", error);
      }
    });
    
    socket.on("disconnect", () => {
      connectedUsers.delete(socket.id);
      console.log("Cliente desconectado:", socket.id);
    });
  });
  
  // Endpoint de upload de arquivos com estrutura de pastas por cliente
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "Nenhum arquivo enviado" });
      }
      
      const clientId = req.body.clientId || 'general';
      const timestamp = Date.now();
      const randomSuffix = Math.random().toString(36).substring(7);
      const fileName = req.file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
      
      // Estrutura de pastas: /clients/{clientId}/documents/{timestamp}_{random}_{fileName}
      const fileKey = `clients/${clientId}/documents/${timestamp}_${randomSuffix}_${fileName}`;
      
      // Upload para S3
      const { url } = await storagePut(
        fileKey,
        req.file.buffer,
        req.file.mimetype
      );
      
      console.log(`Arquivo enviado para S3: ${fileKey}`);
      
      // Processar OCR em background (não bloqueia resposta)
      let extractedText: string | null = null;
      try {
        console.log(`Iniciando OCR para ${req.file.originalname}...`);
        extractedText = await extractTextFromDocument(req.file.buffer, req.file.mimetype);
        if (extractedText) {
          console.log(`OCR concluído: ${extractedText.length} caracteres extraídos`);
        } else {
          console.log('OCR não aplicável para este tipo de arquivo');
        }
      } catch (ocrError) {
        console.error('Erro no OCR (não crítico):', ocrError);
        // Não falha o upload se OCR falhar
      }
      
      res.json({
        success: true,
        fileUrl: url,
        fileKey: fileKey,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        extractedText: extractedText
      });
    } catch (error) {
      console.error("Erro no upload:", error);
      res.status(500).json({ error: "Falha no upload" });
    }
  });

  // Endpoint de upload de documentos de processos
  app.post("/api/upload-case-document", upload.single("file"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: "Nenhum arquivo enviado" });
      }
      
      const clientId = req.body.clientId || 'general';
      const caseId = req.body.caseId || 'general';
      const timestamp = Date.now();
      const randomSuffix = Math.random().toString(36).substring(7);
      const fileName = req.file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
      
      // Estrutura de pastas: /clients/{clientId}/cases/{caseId}/documents/{timestamp}_{random}_{fileName}
      const fileKey = `clients/${clientId}/cases/${caseId}/documents/${timestamp}_${randomSuffix}_${fileName}`;
      
      // Upload para S3
      const { url } = await storagePut(
        fileKey,
        req.file.buffer,
        req.file.mimetype
      );
      
      console.log(`Documento do processo enviado para S3: ${fileKey}`);
      
      // Processar OCR em background
      let extractedText: string | null = null;
      try {
        console.log(`Iniciando OCR para ${req.file.originalname}...`);
        extractedText = await extractTextFromDocument(req.file.buffer, req.file.mimetype);
        if (extractedText) {
          console.log(`OCR concluído: ${extractedText.length} caracteres extraídos`);
        }
      } catch (ocrError) {
        console.error('Erro no OCR (não crítico):', ocrError);
      }
      
      res.json({
        success: true,
        fileUrl: url,
        fileKey: fileKey,
        fileName: req.file.originalname,
        fileSize: req.file.size,
        mimeType: req.file.mimetype,
        extractedText: extractedText
      });
    } catch (error) {
      console.error("Erro no upload do documento do processo:", error);
      res.status(500).json({ error: "Falha no upload" });
    }
  });
  
  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
