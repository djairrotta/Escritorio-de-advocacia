import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

// Configurar cliente S3 com credenciais do ambiente
const s3Client = new S3Client({
  region: process.env.AWS_REGION || "us-east-1",
  credentials: {
    accessKeyId: process.env.AWS_ACCESS_KEY_ID || "",
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY || "",
  },
});

const BUCKET_NAME = process.env.S3_BUCKET_NAME || "manus-storage";

/**
 * Faz upload de um arquivo para o S3
 * @param fileKey - Caminho do arquivo no S3 (ex: clients/123/documents/file.pdf)
 * @param fileBuffer - Buffer do arquivo
 * @param contentType - Tipo MIME do arquivo
 * @returns URL pública do arquivo
 */
export async function storagePut(
  fileKey: string,
  fileBuffer: Buffer | Uint8Array | string,
  contentType?: string
): Promise<{ url: string; key: string }> {
  try {
    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: fileKey,
      Body: fileBuffer,
      ContentType: contentType,
    });

    await s3Client.send(command);

    // URL pública do arquivo
    const url = `https://${BUCKET_NAME}.s3.amazonaws.com/${fileKey}`;

    return { url, key: fileKey };
  } catch (error) {
    console.error("Erro ao fazer upload para S3:", error);
    throw new Error("Falha no upload para S3");
  }
}

/**
 * Gera URL pré-assinada para download de arquivo privado
 * @param fileKey - Caminho do arquivo no S3
 * @param expiresIn - Tempo de expiração em segundos (padrão: 3600 = 1 hora)
 * @returns URL pré-assinada
 */
export async function storageGet(
  fileKey: string,
  expiresIn: number = 3600
): Promise<{ url: string; key: string }> {
  // Implementação simplificada - retorna URL pública
  // Em produção, usar GetObjectCommand com presigned URL
  const url = `https://${BUCKET_NAME}.s3.amazonaws.com/${fileKey}`;
  return { url, key: fileKey };
}
