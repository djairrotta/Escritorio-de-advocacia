import Tesseract from 'tesseract.js';
import * as pdfParse from 'pdf-parse';

/**
 * Extrai texto de uma imagem usando Tesseract OCR
 */
export async function extractTextFromImage(buffer: Buffer): Promise<string> {
  try {
    const result = await Tesseract.recognize(
      buffer,
      'por', // Português
      {
        logger: (m) => {
          if (m.status === 'recognizing text') {
            console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
          }
        }
      }
    );
    
    return result.data.text.trim();
  } catch (error) {
    console.error('Erro ao extrair texto da imagem:', error);
    throw new Error('Falha no OCR da imagem');
  }
}

/**
 * Extrai texto de um PDF
 */
export async function extractTextFromPDF(buffer: Buffer): Promise<string> {
  try {
    // @ts-ignore - pdf-parse usa CommonJS
    const parse = (await import('pdf-parse')).default || pdfParse;
    const data = await parse(buffer);
    return data.text.trim();
  } catch (error) {
    console.error('Erro ao extrair texto do PDF:', error);
    throw new Error('Falha ao processar PDF');
  }
}

/**
 * Processa documento e extrai texto baseado no tipo MIME
 */
export async function extractTextFromDocument(
  buffer: Buffer, 
  mimeType: string
): Promise<string | null> {
  try {
    // PDFs
    if (mimeType === 'application/pdf') {
      console.log('Processando PDF com pdf-parse...');
      return await extractTextFromPDF(buffer);
    }
    
    // Imagens
    if (mimeType.startsWith('image/')) {
      console.log('Processando imagem com Tesseract OCR...');
      return await extractTextFromImage(buffer);
    }
    
    // Documentos do Word (não suportado nativamente, retorna null)
    if (
      mimeType === 'application/msword' || 
      mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ) {
      console.log('Tipo de documento Word detectado - OCR não disponível');
      return null;
    }
    
    console.log(`Tipo MIME não suportado para OCR: ${mimeType}`);
    return null;
  } catch (error) {
    console.error('Erro ao extrair texto do documento:', error);
    return null;
  }
}

/**
 * Normaliza texto para busca (remove acentos, converte para minúsculas)
 */
export function normalizeTextForSearch(text: string): string {
  return text
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .replace(/[^\w\s]/g, ' ') // Remove pontuação
    .replace(/\s+/g, ' ') // Normaliza espaços
    .trim();
}

/**
 * Verifica se o texto contém a palavra-chave (busca insensível a acentos)
 */
export function searchInText(text: string, keyword: string): boolean {
  const normalizedText = normalizeTextForSearch(text);
  const normalizedKeyword = normalizeTextForSearch(keyword);
  return normalizedText.includes(normalizedKeyword);
}
