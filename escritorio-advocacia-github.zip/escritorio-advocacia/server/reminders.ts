import cron from "node-cron";
// Importar funções de notificação
// Em produção, usar serviço real de e-mail e WhatsApp

interface TimeSlot {
  id: string;
  date: string;
  startTime: string;
  endTime: string;
  advogadoId: string;
  advogadoName: string;
  status: "disponivel" | "solicitado" | "confirmado";
  clienteName?: string;
  clienteEmail?: string;
  clientePhone?: string;
}

// Função para verificar agendamentos e enviar lembretes
export async function checkAndSendReminders() {
  try {
    // Carregar agendamentos do localStorage (em produção, usar banco de dados)
    const slots: TimeSlot[] = JSON.parse(
      global.localStorage?.getItem("available_time_slots") || "[]"
    );

    // Data de amanhã (24h a partir de agora)
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split("T")[0]; // YYYY-MM-DD

    // Filtrar agendamentos confirmados para amanhã
    const upcomingAppointments = slots.filter(
      (slot) => slot.status === "confirmado" && slot.date === tomorrowStr
    );

    console.log(
      `[Reminders] Verificando lembretes para ${tomorrowStr}: ${upcomingAppointments.length} agendamentos encontrados`
    );

    // Enviar lembrete para cada agendamento
    for (const appointment of upcomingAppointments) {
      await sendReminderToClient(appointment);
      await sendReminderToAdvogado(appointment);
    }

    return {
      success: true,
      count: upcomingAppointments.length,
      date: tomorrowStr,
    };
  } catch (error) {
    console.error("[Reminders] Erro ao verificar lembretes:", error);
    return { success: false, error: String(error) };
  }
}

// Enviar lembrete para o cliente
async function sendReminderToClient(appointment: TimeSlot) {
  if (!appointment.clienteEmail) return;

  const appointmentDate = new Date(appointment.date + "T00:00:00");
  const formattedDate = appointmentDate.toLocaleDateString("pt-BR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Template de e-mail
  const emailSubject = "Lembrete: Consulta Agendada Amanhã";
  const emailBody = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #1e293b;">Lembrete de Consulta</h2>
      
      <p>Olá, <strong>${appointment.clienteName}</strong>!</p>
      
      <p>Este é um lembrete de que você tem uma consulta agendada para <strong>amanhã</strong>:</p>
      
      <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
        <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.startTime} - ${appointment.endTime}</p>
        <p style="margin: 5px 0;"><strong>Advogado:</strong> ${appointment.advogadoName}</p>
      </div>
      
      <p>Por favor, confirme sua presença respondendo este e-mail ou entrando em contato conosco.</p>
      
      <p style="margin-top: 30px;">
        <a href="https://wa.me/551936564903?text=Confirmo%20minha%20presença%20na%20consulta%20de%20amanhã" 
           style="background-color: #1e293b; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
          Confirmar via WhatsApp
        </a>
      </p>
      
      <p style="color: #64748b; font-size: 14px; margin-top: 30px;">
        Atenciosamente,<br>
        <strong>Djair Rota Advogados</strong><br>
        (19) 3656-4903
      </p>
    </div>
  `;

  try {
    // TODO: Integrar com serviço real de e-mail
    console.log(`[Reminders] E-mail seria enviado para ${appointment.clienteEmail}`);
    console.log(`[Reminders] Assunto: ${emailSubject}`);
  } catch (error) {
    console.error(
      `[Reminders] Erro ao enviar e-mail para ${appointment.clienteEmail}:`,
      error
    );
  }

  // Enviar WhatsApp (se telefone disponível)
  if (appointment.clientePhone) {
    const whatsappMessage = `🔔 *Lembrete de Consulta*\n\nOlá, ${appointment.clienteName}!\n\nVocê tem uma consulta agendada para *amanhã*:\n\n📅 Data: ${formattedDate}\n🕐 Horário: ${appointment.startTime} - ${appointment.endTime}\n👨‍⚖️ Advogado: ${appointment.advogadoName}\n\nPor favor, confirme sua presença!\n\n_Djair Rota Advogados_\n(19) 3656-4903`;

    try {
      // TODO: Integrar com API WhatsApp Business
      console.log(
        `[Reminders] WhatsApp seria enviado para ${appointment.clientePhone}`
      );
      console.log(`[Reminders] Mensagem: ${whatsappMessage}`);
    } catch (error) {
      console.error(
        `[Reminders] Erro ao enviar WhatsApp para ${appointment.clientePhone}:`,
        error
      );
    }
  }
}

// Enviar lembrete para o advogado
async function sendReminderToAdvogado(appointment: TimeSlot) {
  const appointmentDate = new Date(appointment.date + "T00:00:00");
  const formattedDate = appointmentDate.toLocaleDateString("pt-BR", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  // Buscar e-mail do advogado (em produção, buscar do banco de dados)
  const advogadoEmail = `advogado${appointment.advogadoId}@djairrotta.com.br`;

  const emailSubject = "Lembrete: Consulta Agendada Amanhã";
  const emailBody = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #1e293b;">Lembrete de Consulta</h2>
      
      <p>Olá, <strong>${appointment.advogadoName}</strong>!</p>
      
      <p>Você tem uma consulta agendada para <strong>amanhã</strong>:</p>
      
      <div style="background-color: #f1f5f9; padding: 20px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 5px 0;"><strong>Cliente:</strong> ${appointment.clienteName}</p>
        <p style="margin: 5px 0;"><strong>Data:</strong> ${formattedDate}</p>
        <p style="margin: 5px 0;"><strong>Horário:</strong> ${appointment.startTime} - ${appointment.endTime}</p>
        ${appointment.clienteEmail ? `<p style="margin: 5px 0;"><strong>E-mail:</strong> ${appointment.clienteEmail}</p>` : ""}
        ${appointment.clientePhone ? `<p style="margin: 5px 0;"><strong>Telefone:</strong> ${appointment.clientePhone}</p>` : ""}
      </div>
      
      <p style="color: #64748b; font-size: 14px; margin-top: 30px;">
        Sistema de Lembretes Automáticos<br>
        <strong>Djair Rota Advogados</strong>
      </p>
    </div>
  `;

  try {
    // TODO: Integrar com serviço real de e-mail
    console.log(`[Reminders] E-mail seria enviado para ${advogadoEmail}`);
    console.log(`[Reminders] Assunto: ${emailSubject}`);
  } catch (error) {
    console.error(
      `[Reminders] Erro ao enviar e-mail para ${advogadoEmail}:`,
      error
    );
  }
}

// Agendar verificação diária às 9h
export function startReminderScheduler() {
  // Executar todos os dias às 9h (horário do servidor)
  cron.schedule("0 9 * * *", async () => {
    console.log("[Reminders] Iniciando verificação diária de lembretes...");
    const result = await checkAndSendReminders();
    console.log("[Reminders] Resultado:", result);
  });

  console.log("[Reminders] Scheduler iniciado - verificação diária às 9h");
}

// Função para teste manual
export async function testReminders() {
  console.log("[Reminders] Executando teste manual de lembretes...");
  return await checkAndSendReminders();
}
