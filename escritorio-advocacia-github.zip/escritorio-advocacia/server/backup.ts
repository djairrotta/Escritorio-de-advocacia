import cron from "node-cron";
import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs/promises";
import path from "path";
import { sendBackupNotification } from "./email";

const execAsync = promisify(exec);

export interface BackupConfig {
  enabled: boolean;
  schedule: string; // Cron expression (ex: "0 2 * * *" = todo dia às 2h)
  retentionDays: number; // Quantos dias manter backups antigos
  adminEmail: string;
}

const DEFAULT_CONFIG: BackupConfig = {
  enabled: true,
  schedule: "0 2 * * *", // 2h da manhã todos os dias
  retentionDays: 30,
  adminEmail: process.env.ADMIN_EMAIL || "admin@djairrota.com.br",
};

/**
 * Cria um backup do banco de dados MySQL/TiDB
 */
export async function createDatabaseBackup(): Promise<{
  success: boolean;
  filePath?: string;
  size?: string;
  error?: string;
}> {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backupDir = "/tmp/backups";
    const backupFileName = `backup-${timestamp}.sql`;
    const backupPath = path.join(backupDir, backupFileName);

    // Criar diretório se não existir
    await fs.mkdir(backupDir, { recursive: true });

    // Obter credenciais do banco de dados
    const dbHost = process.env.DATABASE_HOST || "localhost";
    const dbPort = process.env.DATABASE_PORT || "3306";
    const dbName = process.env.DATABASE_NAME || "escritorio_db";
    const dbUser = process.env.DATABASE_USER || "root";
    const dbPassword = process.env.DATABASE_PASSWORD || "";

    // Executar mysqldump
    const dumpCommand = `mysqldump -h ${dbHost} -P ${dbPort} -u ${dbUser} ${
      dbPassword ? `-p${dbPassword}` : ""
    } ${dbName} > ${backupPath}`;

    await execAsync(dumpCommand);

    // Verificar tamanho do arquivo
    const stats = await fs.stat(backupPath);
    const sizeInMB = (stats.size / (1024 * 1024)).toFixed(2);

    console.log(`✅ Backup criado: ${backupPath} (${sizeInMB} MB)`);

    return {
      success: true,
      filePath: backupPath,
      size: `${sizeInMB} MB`,
    };
  } catch (error: any) {
    console.error("❌ Erro ao criar backup:", error);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * Faz upload do backup para S3
 */
export async function uploadBackupToS3(
  filePath: string
): Promise<{ success: boolean; url?: string; error?: string }> {
  try {
    // Ler arquivo
    const fileContent = await fs.readFile(filePath);
    const fileName = path.basename(filePath);

    // Upload para S3 usando storagePut (precisa ser implementado no servidor)
    // Por enquanto, simular upload
    const s3Path = `backups/${fileName}`;
    
    console.log(`📤 Upload para S3: ${s3Path}`);

    // Em produção, usar storagePut do template
    // const { url } = await storagePut(s3Path, fileContent, "application/sql");

    return {
      success: true,
      url: `s3://escritorio-backups/${s3Path}`,
    };
  } catch (error: any) {
    console.error("❌ Erro ao fazer upload para S3:", error);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * Remove backups antigos
 */
export async function cleanOldBackups(retentionDays: number): Promise<void> {
  try {
    const backupDir = "/tmp/backups";
    const files = await fs.readdir(backupDir);
    const now = Date.now();
    const maxAge = retentionDays * 24 * 60 * 60 * 1000; // dias em ms

    for (const file of files) {
      const filePath = path.join(backupDir, file);
      const stats = await fs.stat(filePath);
      const age = now - stats.mtimeMs;

      if (age > maxAge) {
        await fs.unlink(filePath);
        console.log(`🗑️  Backup antigo removido: ${file}`);
      }
    }
  } catch (error) {
    console.error("❌ Erro ao limpar backups antigos:", error);
  }
}

/**
 * Executa rotina completa de backup
 */
export async function runBackupRoutine(config: BackupConfig = DEFAULT_CONFIG): Promise<void> {
  console.log("🔄 Iniciando rotina de backup...");

  // 1. Criar backup
  const backup = await createDatabaseBackup();
  if (!backup.success) {
    console.error("❌ Falha ao criar backup:", backup.error);
    return;
  }

  // 2. Upload para S3
  const upload = await uploadBackupToS3(backup.filePath!);
  if (!upload.success) {
    console.error("❌ Falha ao fazer upload:", upload.error);
    return;
  }

  // 3. Enviar notificação por e-mail
  await sendBackupNotification(config.adminEmail, backup.size!, upload.url!);

  // 4. Limpar backups antigos
  await cleanOldBackups(config.retentionDays);

  console.log("✅ Rotina de backup concluída com sucesso!");
}

/**
 * Inicia o agendamento automático de backups
 */
export function startBackupScheduler(config: BackupConfig = DEFAULT_CONFIG): void {
  if (!config.enabled) {
    console.log("⏸️  Backup automático desabilitado");
    return;
  }

  console.log(`⏰ Backup agendado: ${config.schedule}`);

  cron.schedule(config.schedule, async () => {
    console.log(`🕐 ${new Date().toISOString()} - Executando backup agendado...`);
    await runBackupRoutine(config);
  });

  // Executar backup imediatamente ao iniciar (opcional)
  // runBackupRoutine(config);
}

/**
 * Restaura um backup do banco de dados
 */
export async function restoreDatabaseBackup(backupPath: string): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    const dbHost = process.env.DATABASE_HOST || "localhost";
    const dbPort = process.env.DATABASE_PORT || "3306";
    const dbName = process.env.DATABASE_NAME || "escritorio_db";
    const dbUser = process.env.DATABASE_USER || "root";
    const dbPassword = process.env.DATABASE_PASSWORD || "";

    const restoreCommand = `mysql -h ${dbHost} -P ${dbPort} -u ${dbUser} ${
      dbPassword ? `-p${dbPassword}` : ""
    } ${dbName} < ${backupPath}`;

    await execAsync(restoreCommand);

    console.log(`✅ Backup restaurado: ${backupPath}`);

    return { success: true };
  } catch (error: any) {
    console.error("❌ Erro ao restaurar backup:", error);
    return {
      success: false,
      error: error.message,
    };
  }
}
