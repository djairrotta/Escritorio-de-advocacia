import bcrypt from "bcryptjs";
import * as db from "./db";

async function seed() {
  console.log("🌱 Iniciando seed do banco de dados...");

  try {
    // Criar usuário Master
    const masterPassword = await bcrypt.hash("admin123", 10);
    const masterId = await db.createUser({
      name: "Dr. Djair Rota",
      email: "admin@djairrotta.com.br",
      password: masterPassword,
      role: "master",
      oab: "OAB/SP 123456",
      phone: "(19) 3656-4903",
    });
    console.log("✅ Usuário Master criado:", masterId);

    // Criar cliente de teste
    const clientPassword = await bcrypt.hash("cliente123", 10);
    const clientId = await db.createClient({
      name: "Maria Silva",
      email: "cliente@exemplo.com",
      password: clientPassword,
      cpf: "123.456.789-00",
      phone: "(19) 99999-3333",
      address: "Rua das Flores, 123",
      city: "Mococa",
      state: "SP",
      zipCode: "13730-000",
    });
    console.log("✅ Cliente criado:", clientId);

    // Criar processo
    const caseId = await db.createLegalCase({
      caseNumber: "1234567-89.2024.8.26.0000",
      title: "Ação Trabalhista - Horas Extras",
      description: "Ação trabalhista para cobrança de horas extras não pagas.",
      area: "Trabalhista",
      status: "ativo",
      court: "1ª Vara do Trabalho de Mococa",
      clientId: clientId,
      assignedToId: masterId,
    });
    console.log("✅ Processo criado:", caseId);

    // Criar evento
    const eventId = await db.createCalendarEvent({
      title: "Audiência de Conciliação",
      type: "audiencia",
      startDate: new Date("2024-12-15T14:00:00"),
      endDate: new Date("2024-12-15T15:00:00"),
      allDay: false,
      phone: "(19) 99999-3333",
      notes: "Audiência trabalhista",
      legalCaseId: caseId,
      createdById: masterId,
    });
    console.log("✅ Evento criado:", eventId);

    console.log("\n🎉 Seed concluído!");
    console.log("\n📝 Credenciais:");
    console.log("Master: admin@djairrotta.com.br / admin123");
    console.log("Cliente: cliente@exemplo.com / cliente123");
    
    process.exit(0);
  } catch (error) {
    console.error("❌ Erro:", error);
    process.exit(1);
  }
}

seed();
