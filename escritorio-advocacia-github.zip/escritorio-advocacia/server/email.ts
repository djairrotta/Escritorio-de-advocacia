import nodemailer from "nodemailer";
import type { Transporter } from "nodemailer";

export interface EmailConfig {
  provider: "gmail" | "outlook" | "custom";
  email: string;
  password: string;
  smtpHost?: string;
  smtpPort?: number;
  imapHost?: string;
  imapPort?: number;
}

export interface EmailMessage {
  from: string;
  to: string;
  subject: string;
  body: string;
  html?: string;
  attachments?: Array<{
    filename: string;
    path: string;
  }>;
}

/**
 * Cria um transporter SMTP baseado na configuração
 */
export function createEmailTransporter(config: EmailConfig): Transporter {
  let transportConfig: any;

  switch (config.provider) {
    case "gmail":
      transportConfig = {
        service: "gmail",
        auth: {
          user: config.email,
          pass: config.password,
        },
      };
      break;

    case "outlook":
      transportConfig = {
        service: "hotmail",
        auth: {
          user: config.email,
          pass: config.password,
        },
      };
      break;

    case "custom":
      transportConfig = {
        host: config.smtpHost,
        port: config.smtpPort || 587,
        secure: config.smtpPort === 465,
        auth: {
          user: config.email,
          pass: config.password,
        },
      };
      break;

    default:
      throw new Error("Provider não suportado");
  }

  return nodemailer.createTransport(transportConfig);
}

/**
 * Envia um e-mail usando o transporter configurado
 */
export async function sendEmail(
  transporter: Transporter,
  message: EmailMessage
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const info = await transporter.sendMail({
      from: message.from,
      to: message.to,
      subject: message.subject,
      text: message.body,
      html: message.html || message.body.replace(/\n/g, "<br>"),
      attachments: message.attachments,
    });

    return {
      success: true,
      messageId: info.messageId,
    };
  } catch (error: any) {
    console.error("Erro ao enviar e-mail:", error);
    return {
      success: false,
      error: error.message,
    };
  }
}

/**
 * Verifica se as credenciais de e-mail são válidas
 */
export async function verifyEmailCredentials(config: EmailConfig): Promise<boolean> {
  try {
    const transporter = createEmailTransporter(config);
    await transporter.verify();
    return true;
  } catch (error) {
    console.error("Erro ao verificar credenciais:", error);
    return false;
  }
}

/**
 * Envia e-mail de notificação do sistema
 */
export async function sendSystemNotification(
  to: string,
  subject: string,
  body: string
): Promise<boolean> {
  // Usar configuração do sistema (armazenada no banco ou env)
  const systemConfig: EmailConfig = {
    provider: "gmail",
    email: process.env.SYSTEM_EMAIL || "sistema@djairrota.com.br",
    password: process.env.SYSTEM_EMAIL_PASSWORD || "",
  };

  try {
    const transporter = createEmailTransporter(systemConfig);
    const result = await sendEmail(transporter, {
      from: systemConfig.email,
      to,
      subject,
      body,
    });

    return result.success;
  } catch (error) {
    console.error("Erro ao enviar notificação:", error);
    return false;
  }
}

/**
 * Envia e-mail de backup completado
 */
export async function sendBackupNotification(
  adminEmail: string,
  backupSize: string,
  backupPath: string
): Promise<void> {
  const subject = "✅ Backup do Banco de Dados Concluído";
  const body = `
Backup automático realizado com sucesso!

📊 Detalhes:
- Data/Hora: ${new Date().toLocaleString("pt-BR")}
- Tamanho: ${backupSize}
- Localização: ${backupPath}

O backup foi armazenado com segurança no S3.

---
Sistema de Gestão Jurídica - Djair Rota Advogados
  `.trim();

  await sendSystemNotification(adminEmail, subject, body);
}

/**
 * Envia e-mail de teste
 */
export async function sendTestEmail(config: EmailConfig): Promise<{
  success: boolean;
  error?: string;
}> {
  try {
    const transporter = createEmailTransporter(config);
    const result = await sendEmail(transporter, {
      from: config.email,
      to: config.email,
      subject: "🧪 Teste de Configuração de E-mail",
      body: "Este é um e-mail de teste. Se você recebeu esta mensagem, sua configuração está correta!",
    });

    return result;
  } catch (error: any) {
    return {
      success: false,
      error: error.message,
    };
  }
}
